package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GameCatalogData
import com.example.model.DemoType
import com.example.model.GameCategory
import com.example.viewmodel.GameHubViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("REENA 3D", appName)
    }

    @Test
    fun `game catalog contains more than 100 titles`() {
        val games = GameCatalogData.games
        assertTrue("Expected 100+ games, found ${games.size}", games.size >= 100)
    }

    @Test
    fun `verify playable demos exist for core genres`() {
        val games = GameCatalogData.games
        val aviator = games.find { it.demoType == DemoType.AVIATOR_FLIGHT }
        val racer = games.find { it.demoType == DemoType.CYBER_RACER }
        val puzzle = games.find { it.demoType == DemoType.QUANTUM_PUZZLE }
        val adventure = games.find { it.demoType == DemoType.NEON_RUNNER }

        assertTrue(aviator != null && aviator.isPlayableDemo)
        assertTrue(racer != null && racer.isPlayableDemo)
        assertTrue(puzzle != null && puzzle.isPlayableDemo)
        assertTrue(adventure != null && adventure.isPlayableDemo)
    }

    @Test
    fun `wallet faucet increments balance and logs virtual transaction`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val vm = GameHubViewModel(app)
        val initialBalance = vm.uiState.value.wallet.balance
        vm.claimDailyFaucet()
        assertTrue(initialBalance >= 0)
    }

    @Test
    fun `verify premium membership system and themes`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val vm = GameHubViewModel(app)

        // Verify themes enum has all 4 IMAX themes
        val themes = com.example.data.local.AppThemeMode.values()
        assertEquals(4, themes.size)

        // Verify adult authorization required to unlock VIP
        vm.unlockVipMembership(adultConsent = true)
        vm.setActiveTheme(com.example.data.local.AppThemeMode.ROYAL_GOLD)
    }

    @Test
    fun `verify all games are free to play with no real-money charges`() {
        val games = GameCatalogData.games
        assertTrue(games.all { !it.title.contains("deposit", ignoreCase = true) })
        assertTrue(games.all { !it.description.contains("cash out", ignoreCase = true) })
    }
}

