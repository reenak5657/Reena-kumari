package com.example.data.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class MembershipRepository(private val membershipDao: MembershipDao) {

    val membershipFlow: Flow<MembershipEntity> = membershipDao.getMembershipFlow().map { entity ->
        entity ?: MembershipEntity(id = 1, isVip = false, vipTierTitle = "Standard Gamer", activeTheme = AppThemeMode.DEFAULT_IMAX.name)
    }

    val purchasesFlow: Flow<List<PurchaseEntity>> = membershipDao.getAllPurchasesFlow()

    suspend fun ensureInitialized() {
        val current = membershipDao.getMembershipDirect()
        if (current == null) {
            val initial = MembershipEntity(
                id = 1,
                isVip = false,
                vipTierTitle = "Standard Gamer",
                activeTheme = AppThemeMode.DEFAULT_IMAX.name
            )
            membershipDao.insertOrUpdateMembership(initial)
        }
    }

    suspend fun unlockVipMembership(adultConsentConfirmed: Boolean): PurchaseEntity {
        val orderId = "GPA.${(1000..9999).random()}-${(1000..9999).random()}-${(1000..9999).random()}-${(10000..99999).random()}"
        val purchase = PurchaseEntity(
            orderId = orderId,
            productTitle = "REENA 3D VIP Elite Lifetime Pass",
            amountInr = 10,
            purchaseTimestamp = System.currentTimeMillis(),
            status = "COMPLETED",
            paymentProvider = "Google Play In-App Billing",
            adultAuthorizationConfirmed = adultConsentConfirmed
        )
        membershipDao.insertPurchase(purchase)

        val updated = MembershipEntity(
            id = 1,
            isVip = true,
            vipTierTitle = "VIP Elite Member",
            activeTheme = AppThemeMode.ROYAL_GOLD.name, // Auto-select golden theme
            unlockedAtTimestamp = System.currentTimeMillis()
        )
        membershipDao.insertOrUpdateMembership(updated)
        return purchase
    }

    suspend fun setActiveTheme(theme: AppThemeMode) {
        membershipDao.updateActiveTheme(theme.name)
    }
}
