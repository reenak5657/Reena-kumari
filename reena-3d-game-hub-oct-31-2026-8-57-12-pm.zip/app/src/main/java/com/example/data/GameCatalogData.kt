package com.example.data

import com.example.model.DemoType
import com.example.model.GameCategory
import com.example.model.GameItem

object GameCatalogData {

    val games: List<GameItem> by lazy {
        val list = mutableListOf<GameItem>()

        // 1. Playable Aviator Hero Game
        list.add(
            GameItem(
                id = "aviator_supersonic",
                title = "Aviator 3D: Supersonic Stratosphere",
                category = GameCategory.AVIATOR,
                rating = 4.98f,
                playCount = "2.4M",
                description = "Experience the ultimate IMAX-grade non-betting flight arcade. Pilot a Mach-5 jet into the upper atmosphere, time your safe banking maneuvers before supersonic stall, and rack up massive virtual multiplier points!",
                tags = listOf("3D Flight", "High Stakes", "Supersonic", "Arcade", "Multiplayer Feel"),
                isPlayableDemo = true,
                demoType = DemoType.AVIATOR_FLIGHT,
                primaryColorHex = 0xFF00E5FF,
                secondaryColorHex = 0xFFBD00FF,
                badge = "PLAYABLE HERO"
            )
        )

        // 2. Playable Cyber Racer Hero Game
        list.add(
            GameItem(
                id = "cyber_racer_3d",
                title = "Cyber Velocity: Neon Highway 2099",
                category = GameCategory.RACING,
                rating = 4.94f,
                playCount = "1.8M",
                description = "High-octane 3D perspective cyber highway racer. Dodge futuristic traffic, hit neon speed turbo boosts, collect energy cores and set blistering lap records through the glowing neo-megacity.",
                tags = listOf("3D Racing", "Cyberpunk", "Speed", "Reflex", "Turbo Boost"),
                isPlayableDemo = true,
                demoType = DemoType.CYBER_RACER,
                primaryColorHex = 0xFFFF1744,
                secondaryColorHex = 0xFF00E5FF,
                badge = "PLAYABLE 3D"
            )
        )

        // 3. Playable Neon Matrix Puzzle Game
        list.add(
            GameItem(
                id = "quantum_matrix_puzzle",
                title = "Quantum Grid: Neon Matrix 2048",
                category = GameCategory.PUZZLE,
                rating = 4.91f,
                playCount = "1.5M",
                description = "Synthesize quantum memory nodes in a glowing holographic cyber grid. Slide tiles in 4 directions to fuse identical matrix chips until you crack the 2048 Neural Core!",
                tags = listOf("Cyber Puzzle", "Brain Teaser", "Matrix", "Haptic", "Neon Grid"),
                isPlayableDemo = true,
                demoType = DemoType.QUANTUM_PUZZLE,
                primaryColorHex = 0xFF00E676,
                secondaryColorHex = 0xFF00E5FF,
                badge = "PLAYABLE PUZZLE"
            )
        )

        // 4. Playable 3D Adventure Game
        list.add(
            GameItem(
                id = "neon_runner_adventure",
                title = "Neon Void: 3D Cyber Dungeon",
                category = GameCategory.ADVENTURE,
                rating = 4.88f,
                playCount = "1.2M",
                description = "Descend into glowing cybernetic dungeons! Dodge laser fences, trigger pulse shields, defeat rogue security drones, and claim rare quantum relics across subterranean neon floors.",
                tags = listOf("3D Adventure", "Rogue Runner", "Dungeon", "Action", "Loot"),
                isPlayableDemo = true,
                demoType = DemoType.NEON_RUNNER,
                primaryColorHex = 0xFFBD00FF,
                secondaryColorHex = 0xFFFFB300,
                badge = "PLAYABLE 3D"
            )
        )

        // Category seed titles to generate 100+ distinct slots
        val aviatorTitles = listOf(
            "Nebula Glider X", "Cloud Phantom 3D", "Stratosphere Jet 7", "Solar Wind Glider",
            "Mach Vector Horizon", "Aero Pulse Fighter", "Hyperion Air Command", "Valkyrie Warp",
            "Thunderbird 2099", "Sky Surfer Velocity", "Cosmic Phoenix", "Apex Skyfall",
            "Vortex Interceptor", "Aurora Falcon", "Zephyr Stealth Jet", "Orbital Ascent 3D"
        )

        val racingTitles = listOf(
            "Hyper Drift Tokyo", "Photon Grand Prix", "Gravity Rush 3D", "Turbo Circuit X",
            "Apex Asphalt 2088", "Nitro Shockwave", "Laser Track Cyber", "MagLev Underground",
            "Redline Hypercar", "Ion Storm Drag", "Neon Horizon Rally", "Overdrive Syndicate",
            "Midnight Apex 3D", "Pulse Accelerator", "Cyber Formula One", "Velocity Strike"
        )

        val puzzleTitles = listOf(
            "Neural Link Decoder", "Hexa Core Fusion", "Binary Cyber Maze", "Chroma Block 3D",
            "Quantum Knot Solver", "Laser Prism Reflex", "Data Stream Connect", "Cyber Logic Lock",
            "Neon Sudoku 2099", "Synapse Match 3D", "Holo Cube Twist", "Circuit Breaker X",
            "Matrix Memory Vault", "Zero Point Enigma", "Pixel Flux Grid", "Entropy Harmonizer"
        )

        val adventureTitles = listOf(
            "Shadow Runner: Sector 7", "Solaris Odyssey 3D", "Cyberpunk Chrono Rogue", "Void Nexus Explorer",
            "Abyssal Spire 3D", "Neon Blade: Ronin 2099", "Subterranean Cyber Crypt", "Aero City Parkour",
            "Titan Bastion", "Chrono Shifter 3D", "Starlight Vagabond", "Ghost Protocol: Neo",
            "Neon Samurai Chronicles", "Quantum Expedition", "Lost Colony Alpha", "Obsidian Citadel"
        )

        val sciFiTitles = listOf(
            "Mech Strike 3D: Iron Pulse", "Plasma Arena: Cyber Combat", "Galaxy Enforcer 2099", "Pulse Cannon Orbital",
            "Star Dreadnought Command", "Cyber Siege 3D", "Nano Swarm Vanguard", "Valkyrie Assault",
            "Singularity Protocol", "Ion Blaster Showdown", "Exo Suit Rebellion", "Dark Matter Outpost",
            "Quantum Vanguard 3D", "Astro Marines", "Orbital Cannon Siege", "Hyperion Wars"
        )

        val strategyTitles = listOf(
            "Cosmic Dominion 3D", "Cyber Chess 2099", "Neon Tower Defense", "Quantum Fleet Tactics",
            "Galactic Syndicate 3D", "Synthetic Empire", "A.I. Overlord Protocol", "Stellar Command",
            "Neon Hex Wargame", "Cyber Colony Sim", "Gridiron Tactics 3D", "Omega Corporation",
            "Starlight Alliance", "Sub-Zero Hegemony", "Terraform Project 3D", "Solar Hegemon"
        )

        var counter = 5

        fun addGroup(titles: List<String>, category: GameCategory, primary: Long, secondary: Long, tagsGen: (String) -> List<String>) {
            titles.forEachIndexed { index, title ->
                val rating = 4.5f + ((index * 37) % 49) / 100f
                val plays = "${100 + (index * 47) % 900}K"
                val badges = when {
                    index % 5 == 0 -> "POPULAR"
                    index % 7 == 0 -> "IMAX 3D"
                    index % 9 == 0 -> "NEW"
                    else -> null
                }
                list.add(
                    GameItem(
                        id = "game_slot_${counter}",
                        title = title,
                        category = category,
                        rating = String.format("%.2f", rating).toFloatOrNull() ?: 4.75f,
                        playCount = plays,
                        description = "Embark on an exhilarating experience in $title. Features cutting-edge 3D graphics, responsive touch controls, and competitive virtual leaderboards.",
                        tags = tagsGen(title),
                        isPlayableDemo = false,
                        demoType = DemoType.NONE,
                        primaryColorHex = primary,
                        secondaryColorHex = secondary,
                        badge = badges
                    )
                )
                counter++
            }
        }

        addGroup(aviatorTitles, GameCategory.AVIATOR, 0xFF00E5FF, 0xFF00B0FF) { listOf("Flight", "Sky", "Altitude", "Virtual Thrill") }
        addGroup(racingTitles, GameCategory.RACING, 0xFFFF1744, 0xFFFF5252) { listOf("Racing", "Turbo", "Speedway", "Cyber Drift") }
        addGroup(puzzleTitles, GameCategory.PUZZLE, 0xFF00E676, 0xFF69F0AE) { listOf("Logic", "Puzzle", "Neon Matrix", "Cognitive") }
        addGroup(adventureTitles, GameCategory.ADVENTURE, 0xFFBD00FF, 0xFFE040FB) { listOf("3D Quest", "RPG", "Exploration", "Cyber World") }
        addGroup(sciFiTitles, GameCategory.SCI_FI, 0xFFFFB300, 0xFFFFD54F) { listOf("Action", "Shooter", "Mecha", "Combat") }
        addGroup(strategyTitles, GameCategory.STRATEGY, 0xFF2979FF, 0xFF448AFF) { listOf("Tactics", "Economy", "Command", "Sci-Fi Strategy") }

        // Additional series slots to reach 106 high-quality games!
        val additionalTitles = listOf(
            "Neon Pinball 3D" to GameCategory.AVIATOR,
            "Laser Echoes 2099" to GameCategory.PUZZLE,
            "Cyber Sprint Parkour" to GameCategory.ADVENTURE,
            "Vortex Racer Extreme" to GameCategory.RACING,
            "Solar Flare Outbreak" to GameCategory.SCI_FI,
            "Neural Hacker 3D" to GameCategory.STRATEGY
        )

        additionalTitles.forEach { (title, cat) ->
            list.add(
                GameItem(
                    id = "game_slot_${counter}",
                    title = title,
                    category = cat,
                    rating = 4.86f,
                    playCount = "720K",
                    description = "Special Edition release for REENA 3D GAME HUB. Immerse yourself with IMAX dark mode visuals and smooth framerates.",
                    tags = listOf("Special 3D", "Featured", "Exclusive"),
                    primaryColorHex = 0xFF00E5FF,
                    secondaryColorHex = 0xFFBD00FF,
                    badge = "EXCLUSIVE"
                )
            )
            counter++
        }

        list
    }
}
