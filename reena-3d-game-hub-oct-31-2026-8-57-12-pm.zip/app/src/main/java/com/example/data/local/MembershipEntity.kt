package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AppThemeMode(val displayName: String, val primaryHex: Long, val secondaryHex: Long) {
    DEFAULT_IMAX("IMAX Cyan & Violet", 0xFF00E5FF, 0xFFBD00FF),
    ROYAL_GOLD("Royal Amber Gold", 0xFFFFB300, 0xFFFFD54F),
    MATRIX_EMERALD("Quantum Matrix Green", 0xFF00E676, 0xFF00E5FF),
    DEEP_CRIMSON("Deep Cyber Crimson", 0xFFFF1744, 0xFFBD00FF)
}

@Entity(tableName = "user_membership")
data class MembershipEntity(
    @PrimaryKey
    val id: Int = 1,
    val isVip: Boolean = false,
    val vipTierTitle: String = "Standard Gamer",
    val activeTheme: String = AppThemeMode.DEFAULT_IMAX.name,
    val unlockedAtTimestamp: Long = 0L
)

@Entity(tableName = "purchase_history")
data class PurchaseEntity(
    @PrimaryKey
    val orderId: String,
    val productTitle: String,
    val amountInr: Int,
    val purchaseTimestamp: Long,
    val status: String, // "COMPLETED", "REFUNDED"
    val paymentProvider: String = "Google Play In-App Billing",
    val adultAuthorizationConfirmed: Boolean = true
)
