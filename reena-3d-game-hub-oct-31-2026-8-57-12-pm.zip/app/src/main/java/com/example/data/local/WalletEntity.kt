package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "virtual_wallet")
data class WalletEntity(
    @PrimaryKey
    val id: Int = 1,
    val balance: Long = 5000L,
    val lifetimeEarned: Long = 5000L,
    val lastFaucetTimestamp: Long = 0L
)

@Entity(tableName = "wallet_transactions")
data class TransactionEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val amount: Long,
    val timestamp: Long,
    val type: String
)
