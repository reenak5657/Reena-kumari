package com.example.data.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import java.util.UUID

class WalletRepository(private val walletDao: WalletDao) {

    val walletFlow: Flow<WalletEntity> = walletDao.getWalletFlow().map { entity ->
        entity ?: WalletEntity(id = 1, balance = 5000L, lifetimeEarned = 5000L, lastFaucetTimestamp = 0L)
    }

    val transactionsFlow: Flow<List<TransactionEntity>> = walletDao.getAllTransactionsFlow()

    suspend fun ensureInitialized() {
        val current = walletDao.getWalletDirect()
        if (current == null) {
            val initialWallet = WalletEntity(id = 1, balance = 5000L, lifetimeEarned = 5000L, lastFaucetTimestamp = 0L)
            walletDao.insertOrUpdateWallet(initialWallet)
            val welcomeTx = TransactionEntity(
                id = UUID.randomUUID().toString(),
                title = "Welcome Starter Demo Pack",
                amount = 5000L,
                timestamp = System.currentTimeMillis(),
                type = "STARTER_BONUS"
            )
            walletDao.insertTransaction(welcomeTx)
        }
    }

    suspend fun addCoins(amount: Long, title: String, type: String) {
        val current = walletDao.getWalletDirect() ?: WalletEntity(id = 1, balance = 5000L, lifetimeEarned = 5000L)
        val newBalance = current.balance + amount
        val newLifetime = if (amount > 0) current.lifetimeEarned + amount else current.lifetimeEarned

        val updated = current.copy(balance = newBalance, lifetimeEarned = newLifetime)
        walletDao.insertOrUpdateWallet(updated)

        val tx = TransactionEntity(
            id = UUID.randomUUID().toString(),
            title = title,
            amount = amount,
            timestamp = System.currentTimeMillis(),
            type = type
        )
        walletDao.insertTransaction(tx)
    }

    suspend fun deductCoins(amount: Long, title: String): Boolean {
        val current = walletDao.getWalletDirect() ?: WalletEntity(id = 1, balance = 5000L, lifetimeEarned = 5000L)
        if (current.balance < amount) return false

        val newBalance = current.balance - amount
        val updated = current.copy(balance = newBalance)
        walletDao.insertOrUpdateWallet(updated)

        val tx = TransactionEntity(
            id = UUID.randomUUID().toString(),
            title = title,
            amount = -amount,
            timestamp = System.currentTimeMillis(),
            type = "LAUNCH_FEE"
        )
        walletDao.insertTransaction(tx)
        return true
    }

    suspend fun claimDailyFaucet(): Long {
        val bonus = 1000L
        addCoins(bonus, "Daily Free Demo Faucet", "FAUCET_CLAIM")
        val current = walletDao.getWalletDirect()
        if (current != null) {
            walletDao.insertOrUpdateWallet(current.copy(lastFaucetTimestamp = System.currentTimeMillis()))
        }
        return bonus
    }
}
