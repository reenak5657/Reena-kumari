package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MembershipDao {

    @Query("SELECT * FROM user_membership WHERE id = 1 LIMIT 1")
    fun getMembershipFlow(): Flow<MembershipEntity?>

    @Query("SELECT * FROM user_membership WHERE id = 1 LIMIT 1")
    suspend fun getMembershipDirect(): MembershipEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateMembership(membership: MembershipEntity)

    @Query("UPDATE user_membership SET activeTheme = :themeName WHERE id = 1")
    suspend fun updateActiveTheme(themeName: String)

    @Query("SELECT * FROM purchase_history ORDER BY purchaseTimestamp DESC")
    fun getAllPurchasesFlow(): Flow<List<PurchaseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: PurchaseEntity)

    @Query("SELECT COUNT(*) FROM purchase_history")
    suspend fun getTotalPurchaseCount(): Int

    @Query("SELECT SUM(amountInr) FROM purchase_history")
    suspend fun getTotalSalesRevenue(): Int?
}
