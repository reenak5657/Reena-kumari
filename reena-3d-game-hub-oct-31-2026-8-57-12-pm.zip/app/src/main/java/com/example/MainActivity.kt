package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.DemoType
import com.example.ui.components.NeonBottomNavigationBar
import com.example.ui.components.NeonTopBar
import com.example.ui.components.PremiumMembershipModal
import com.example.ui.components.ThemeSelectorDialog
import com.example.ui.games.AviatorArcadeGame
import com.example.ui.games.CyberRacerGame
import com.example.ui.games.NeonRunnerGame
import com.example.ui.games.QuantumPuzzleGame
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.CatalogScreen
import com.example.ui.screens.GameDetailDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.PurchaseHistoryScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ActiveScreen
import com.example.viewmodel.GameHubViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ReenaGameHubApp()
        }
    }
}

@Composable
fun ReenaGameHubApp(
    viewModel: GameHubViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    MyApplicationTheme(themeMode = state.activeTheme) {
        // Handle back button for sub-screens
        BackHandler(enabled = state.currentScreen !is ActiveScreen.Home) {
            viewModel.navigateTo(ActiveScreen.Home)
        }

        val isPlayingGame = state.currentScreen is ActiveScreen.PlayGame

        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberDarkBg),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (!isPlayingGame && state.currentScreen !is ActiveScreen.AdminDashboard) {
                    NeonTopBar(
                        walletBalance = state.wallet.balance,
                        isVip = state.isVip,
                        onWalletClick = { viewModel.navigateTo(ActiveScreen.Wallet) },
                        onVipClick = { viewModel.openVipModal() },
                        onThemeClick = { viewModel.openThemeDialog() },
                        onProfileClick = { viewModel.navigateTo(ActiveScreen.Profile) },
                        onAdminClick = { viewModel.navigateTo(ActiveScreen.AdminDashboard) }
                    )
                }
            },
            bottomBar = {
                if (!isPlayingGame && state.currentScreen !is ActiveScreen.AdminDashboard) {
                    NeonBottomNavigationBar(
                        currentScreen = state.currentScreen,
                        onNavigate = { screen -> viewModel.navigateTo(screen) }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(CyberDarkBg)
            ) {
            when (val screen = state.currentScreen) {
                is ActiveScreen.Home -> {
                    HomeScreen(
                        state = state,
                        onNavigate = { target -> viewModel.navigateTo(target) },
                        onOpenGameDetail = { game -> viewModel.openGameDetail(game) },
                        onPlayDemo = { demoType, title ->
                            viewModel.navigateTo(ActiveScreen.PlayGame(demoType, title))
                        },
                        onToggleFavorite = { id -> viewModel.toggleFavorite(id) },
                        onClaimFaucet = {
                            viewModel.claimDailyFaucet()
                            scope.launch {
                                snackbarHostState.showSnackbar("🪙 +1,000 Free Virtual Demo Coins Claimed!")
                            }
                        }
                    )
                }

                is ActiveScreen.Catalog -> {
                    CatalogScreen(
                        state = state,
                        onSearchChange = { q -> viewModel.setSearchQuery(q) },
                        onCategoryChange = { cat -> viewModel.selectCategory(cat) },
                        onTogglePlayableOnly = { only -> viewModel.toggleOnlyPlayableDemos(only) },
                        onOpenDetail = { game -> viewModel.openGameDetail(game) },
                        onPlayDemo = { demoType, title ->
                            viewModel.navigateTo(ActiveScreen.PlayGame(demoType, title))
                        },
                        onToggleFavorite = { id -> viewModel.toggleFavorite(id) }
                    )
                }

                is ActiveScreen.Wallet -> {
                    WalletScreen(
                        state = state,
                        onClaimFaucet = {
                            viewModel.claimDailyFaucet()
                            scope.launch {
                                snackbarHostState.showSnackbar("🪙 +1,000 Free Demo Faucet Claimed!")
                            }
                        },
                        onClaimBonusPack = { amount, title ->
                            viewModel.recordGameReward(amount, "Voucher Claim", title)
                            scope.launch {
                                snackbarHostState.showSnackbar("🪙 +$amount Demo Coins Added: $title")
                            }
                        }
                    )
                }

                is ActiveScreen.AiAssistant -> {
                    AiAssistantScreen(
                        state = state,
                        onSendMessage = { text -> viewModel.sendAiMessage(text) }
                    )
                }

                is ActiveScreen.Profile -> {
                    ProfileScreen(
                        state = state,
                        onOpenVipModal = { viewModel.openVipModal() },
                        onOpenThemeDialog = { viewModel.openThemeDialog() },
                        onViewPurchases = { viewModel.navigateTo(ActiveScreen.PurchaseHistory) }
                    )
                }

                is ActiveScreen.PurchaseHistory -> {
                    PurchaseHistoryScreen(
                        purchases = state.purchaseHistory,
                        onBack = { viewModel.navigateTo(ActiveScreen.Profile) },
                        onOpenVipOffer = { viewModel.openVipModal() }
                    )
                }

                is ActiveScreen.AdminDashboard -> {
                    AdminDashboardScreen(
                        state = state,
                        onBack = { viewModel.navigateTo(ActiveScreen.Home) },
                        onToggleMaintenance = { viewModel.toggleMaintenanceMode() },
                        onToggleDoubleXp = { viewModel.toggleDoubleXp() },
                        onToggleMegaBonus = { viewModel.toggleMegaBonus() }
                    )
                }

                is ActiveScreen.PlayGame -> {
                    when (screen.demoType) {
                        DemoType.AVIATOR_FLIGHT -> {
                            AviatorArcadeGame(
                                walletBalance = state.wallet.balance,
                                onBack = { viewModel.navigateTo(ActiveScreen.Home) },
                                onRewardEarned = { coins, mult, summary ->
                                    viewModel.recordGameReward(coins, "${String.format("%.2f", mult)}x", summary)
                                    scope.launch {
                                        snackbarHostState.showSnackbar("🚀 Safe Landing! +$coins Virtual Coins Banked!")
                                    }
                                },
                                onDeductCoins = { coins ->
                                    viewModel.deductDemoCoins(coins)
                                }
                            )
                        }

                        DemoType.CYBER_RACER -> {
                            CyberRacerGame(
                                walletBalance = state.wallet.balance,
                                onBack = { viewModel.navigateTo(ActiveScreen.Home) },
                                onRewardEarned = { coins, score, summary ->
                                    viewModel.recordGameReward(coins, score, summary)
                                    scope.launch {
                                        snackbarHostState.showSnackbar("🏎️ Circuit Finished! +$coins Coins Banked!")
                                    }
                                }
                            )
                        }

                        DemoType.QUANTUM_PUZZLE -> {
                            QuantumPuzzleGame(
                                walletBalance = state.wallet.balance,
                                onBack = { viewModel.navigateTo(ActiveScreen.Home) },
                                onRewardEarned = { coins, score, summary ->
                                    viewModel.recordGameReward(coins, score, summary)
                                    scope.launch {
                                        snackbarHostState.showSnackbar("🧩 Matrix Synth Bonus! +$coins Coins!")
                                    }
                                }
                            )
                        }

                        DemoType.NEON_RUNNER -> {
                            NeonRunnerGame(
                                walletBalance = state.wallet.balance,
                                onBack = { viewModel.navigateTo(ActiveScreen.Home) },
                                onRewardEarned = { coins, score, summary ->
                                    viewModel.recordGameReward(coins, score, summary)
                                    scope.launch {
                                        snackbarHostState.showSnackbar("🗡️ Void Floor Complete! +$coins Coins!")
                                    }
                                }
                            )
                        }

                        DemoType.NONE -> {
                            viewModel.navigateTo(ActiveScreen.Home)
                        }
                    }
                }
            }

            // Game Detail Modal Dialog
            state.selectedGameForDetail?.let { selectedGame ->
                GameDetailDialog(
                    game = selectedGame,
                    onDismiss = { viewModel.closeGameDetail() },
                    onPlayDemo = { demoType, title ->
                        viewModel.closeGameDetail()
                        viewModel.navigateTo(ActiveScreen.PlayGame(demoType, title))
                    }
                )
            }

            // VIP Membership Modal
            if (state.showVipModal) {
                PremiumMembershipModal(
                    isVipAlready = state.isVip,
                    onDismiss = { viewModel.closeVipModal() },
                    onPurchaseVipConfirmed = { adultConsent ->
                        viewModel.unlockVipMembership(adultConsent)
                        scope.launch {
                            snackbarHostState.showSnackbar("💎 VIP Elite Membership Activated! +5,000 Coins & All Themes Unlocked!")
                        }
                    }
                )
            }

            // Theme Selector Dialog
            if (state.showThemeDialog) {
                ThemeSelectorDialog(
                    currentTheme = state.activeTheme,
                    isVip = state.isVip,
                    onDismiss = { viewModel.closeThemeDialog() },
                    onSelectTheme = { selectedTheme ->
                        viewModel.setActiveTheme(selectedTheme)
                        viewModel.closeThemeDialog()
                        scope.launch {
                            snackbarHostState.showSnackbar("🎨 Theme switched to ${selectedTheme.displayName}!")
                        }
                    },
                    onOpenVipPrompt = {
                        viewModel.closeThemeDialog()
                        viewModel.openVipModal()
                    }
                )
            }
        }
    }
}
}


