package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GameCatalogData
import com.example.data.local.AppDatabase
import com.example.data.local.AppThemeMode
import com.example.data.local.MembershipRepository
import com.example.data.local.PurchaseEntity
import com.example.data.local.WalletRepository
import com.example.model.Achievement
import com.example.model.AdminPlatformMetrics
import com.example.model.DemoType
import com.example.model.GameCategory
import com.example.model.GameItem
import com.example.model.MatchHistoryItem
import com.example.model.TransactionType
import com.example.model.UserProfile
import com.example.model.WalletState
import com.example.model.WalletTransaction
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

sealed class ActiveScreen {
    object Home : ActiveScreen()
    object Catalog : ActiveScreen()
    object Wallet : ActiveScreen()
    object AiAssistant : ActiveScreen()
    object Profile : ActiveScreen()
    object AdminDashboard : ActiveScreen()
    object PurchaseHistory : ActiveScreen()
    data class PlayGame(val demoType: DemoType, val title: String) : ActiveScreen()
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // "User" or "REENA AI"
    val message: String,
    val isAi: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class GameHubUiState(
    val currentScreen: ActiveScreen = ActiveScreen.Home,
    val allGames: List<GameItem> = emptyList(),
    val searchQuery: String = "",
    val selectedCategory: GameCategory = GameCategory.ALL,
    val onlyPlayableDemos: Boolean = false,
    val selectedGameForDetail: GameItem? = null,
    val wallet: WalletState = WalletState(),
    val userProfile: UserProfile = UserProfile(),
    val adminMetrics: AdminPlatformMetrics = AdminPlatformMetrics(),
    val aiChatMessages: List<ChatMessage> = emptyList(),
    val isAiTyping: Boolean = false,
    val isVip: Boolean = false,
    val activeTheme: AppThemeMode = AppThemeMode.DEFAULT_IMAX,
    val purchaseHistory: List<PurchaseEntity> = emptyList(),
    val showVipModal: Boolean = false,
    val showThemeDialog: Boolean = false
)

class GameHubViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val walletRepository = WalletRepository(database.walletDao())
    private val membershipRepository = MembershipRepository(database.membershipDao())

    private val _uiState = MutableStateFlow(GameHubUiState())
    val uiState: StateFlow<GameHubUiState> = _uiState.asStateFlow()

    init {
        loadInitialStaticData()
        observeRoomDatabase()
    }

    private fun loadInitialStaticData() {
        val gamesList = GameCatalogData.games

        val achievements = listOf(
            Achievement("ach_1", "Sky High Aviator", "Bank a flight above 5.0x multiplier", "🚀", true, 500L),
            Achievement("ach_2", "Speed Demon 2099", "Reach 300+ KM/H on Cyber Highway", "🏎️", true, 350L),
            Achievement("ach_3", "Quantum Synth 1024", "Merge tiles up to 1024 matrix chip", "🧩", true, 400L),
            Achievement("ach_4", "Dungeon Void Master", "Clear Floor 3 in Neon Void 3D", "🗡️", false, 600L),
            Achievement("ach_5", "Virtual Millionaire", "Accumulate 50,000 virtual demo coins", "🪙", false, 1000L)
        )

        val initialHistory = listOf(
            MatchHistoryItem(UUID.randomUUID().toString(), "Aviator 3D: Supersonic", GameCategory.AVIATOR, "5.80x", 580L, System.currentTimeMillis() - 3600000L, "Safe Landing"),
            MatchHistoryItem(UUID.randomUUID().toString(), "Cyber Velocity 2099", GameCategory.RACING, "420 pts", 210L, System.currentTimeMillis() - 7200000L, "Top Speed 320 KM/H"),
            MatchHistoryItem(UUID.randomUUID().toString(), "Quantum Grid 2048", GameCategory.PUZZLE, "1024 Tile", 256L, System.currentTimeMillis() - 14400000L, "Matrix Synthesized"),
            MatchHistoryItem(UUID.randomUUID().toString(), "Neon Void 3D", GameCategory.ADVENTURE, "Floor 2", 300L, System.currentTimeMillis() - 28800000L, "Floor Cleared")
        )

        val welcomeAiMessages = listOf(
            ChatMessage(
                sender = "REENA AI",
                message = "Greetings, Pilot! I am REENA AI, your gaming strategist & tactical assistant. Ask me for gameplay secrets, Aviator banking tips, racer speed drift tricks, or personalized game recommendations from our 100+ titles!",
                isAi = true
            )
        )

        _uiState.update {
            it.copy(
                allGames = gamesList,
                userProfile = UserProfile(
                    achievements = achievements,
                    matchHistory = initialHistory
                ),
                aiChatMessages = welcomeAiMessages
            )
        }
    }

    private fun observeRoomDatabase() {
        viewModelScope.launch {
            walletRepository.ensureInitialized()
            membershipRepository.ensureInitialized()

            // Observe reactive Flow for wallet balance from Room SQLite
            launch {
                walletRepository.walletFlow.collect { walletEntity ->
                    _uiState.update { state ->
                        state.copy(
                            wallet = state.wallet.copy(
                                balance = walletEntity.balance,
                                lastBonusTimestamp = walletEntity.lastFaucetTimestamp
                            ),
                            userProfile = state.userProfile.copy(
                                totalCoinsWon = walletEntity.lifetimeEarned
                            )
                        )
                    }
                }
            }

            // Observe reactive Flow for transactions from Room SQLite
            launch {
                walletRepository.transactionsFlow.collect { entities ->
                    val txList = entities.map { entity ->
                        val txType = when (entity.type) {
                            "FAUCET_CLAIM" -> TransactionType.FAUCET_CLAIM
                            "GAME_WIN" -> TransactionType.GAME_WIN
                            "ACHIEVEMENT_BONUS" -> TransactionType.ACHIEVEMENT_BONUS
                            "PRACTICE_FEE", "LAUNCH_FEE" -> TransactionType.PRACTICE_FEE
                            else -> TransactionType.GAME_WIN
                        }
                        WalletTransaction(
                            id = entity.id,
                            title = entity.title,
                            amount = entity.amount,
                            timestamp = entity.timestamp,
                            type = txType
                        )
                    }
                    _uiState.update { state ->
                        state.copy(wallet = state.wallet.copy(transactions = txList))
                    }
                }
            }

            // Observe reactive Flow for VIP membership from Room SQLite
            launch {
                membershipRepository.membershipFlow.collect { membershipEntity ->
                    val theme = try {
                        AppThemeMode.valueOf(membershipEntity.activeTheme)
                    } catch (_: Exception) {
                        AppThemeMode.DEFAULT_IMAX
                    }
                    _uiState.update { state ->
                        state.copy(
                            isVip = membershipEntity.isVip,
                            activeTheme = theme,
                            userProfile = state.userProfile.copy(
                                title = if (membershipEntity.isVip) "VIP Elite Legend" else "Neon Grandmaster"
                            )
                        )
                    }
                }
            }

            // Observe reactive Flow for purchase receipts from Room SQLite
            launch {
                membershipRepository.purchasesFlow.collect { purchaseEntities ->
                    val totalRev = 14200 + (purchaseEntities.size * 10)
                    val totalPasses = 1420 + purchaseEntities.size
                    _uiState.update { state ->
                        state.copy(
                            purchaseHistory = purchaseEntities,
                            adminMetrics = state.adminMetrics.copy(
                                totalRevenueInr = totalRev,
                                totalVipPassesSold = totalPasses
                            )
                        )
                    }
                }
            }
        }
    }

    fun navigateTo(screen: ActiveScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun selectCategory(category: GameCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun toggleOnlyPlayableDemos(onlyPlayable: Boolean) {
        _uiState.update { it.copy(onlyPlayableDemos = onlyPlayable) }
    }

    fun openGameDetail(game: GameItem) {
        _uiState.update { it.copy(selectedGameForDetail = game) }
    }

    fun closeGameDetail() {
        _uiState.update { it.copy(selectedGameForDetail = null) }
    }

    fun openVipModal() {
        _uiState.update { it.copy(showVipModal = true) }
    }

    fun closeVipModal() {
        _uiState.update { it.copy(showVipModal = false) }
    }

    fun openThemeDialog() {
        _uiState.update { it.copy(showThemeDialog = true) }
    }

    fun closeThemeDialog() {
        _uiState.update { it.copy(showThemeDialog = false) }
    }

    fun toggleFavorite(gameId: String) {
        _uiState.update { state ->
            val updatedGames = state.allGames.map { g ->
                if (g.id == gameId) g.copy(isFavorite = !g.isFavorite) else g
            }
            state.copy(allGames = updatedGames)
        }
    }

    fun unlockVipMembership(adultConsent: Boolean) {
        viewModelScope.launch {
            membershipRepository.unlockVipMembership(adultConsent)
            walletRepository.addCoins(5000L, "VIP Welcome Gift (+5,000 Demo Coins)", "ACHIEVEMENT_BONUS")
        }
    }

    fun setActiveTheme(theme: AppThemeMode) {
        viewModelScope.launch {
            membershipRepository.setActiveTheme(theme)
        }
    }

    fun claimDailyFaucet(): Boolean {
        viewModelScope.launch {
            val amount = if (_uiState.value.isVip) 2000L else 1000L
            walletRepository.addCoins(amount, if (_uiState.value.isVip) "VIP 2x Daily Faucet" else "Daily Free Demo Faucet", "FAUCET_CLAIM")
        }
        return true
    }

    fun recordGameReward(coins: Long, scoreOrMultiplier: String, summary: String) {
        viewModelScope.launch {
            walletRepository.addCoins(coins, summary, "GAME_WIN")
        }

        val historyItem = MatchHistoryItem(
            id = UUID.randomUUID().toString(),
            gameTitle = summary,
            category = GameCategory.AVIATOR,
            scoreOrMultiplier = scoreOrMultiplier,
            virtualCoinsEarned = coins,
            timestamp = System.currentTimeMillis(),
            resultStatus = "Reward Banked"
        )
        val newXp = (_uiState.value.userProfile.currentXp + (coins / 5).toInt()).coerceAtMost(_uiState.value.userProfile.maxXp)

        _uiState.update { state ->
            state.copy(
                userProfile = state.userProfile.copy(
                    totalPlayCount = state.userProfile.totalPlayCount + 1,
                    currentXp = newXp,
                    matchHistory = listOf(historyItem) + state.userProfile.matchHistory
                )
            )
        }
    }

    fun deductDemoCoins(coins: Long): Boolean {
        if (_uiState.value.wallet.balance < coins) return false
        viewModelScope.launch {
            walletRepository.deductCoins(coins, "Practice Round Launch Fee")
        }
        return true
    }

    // AI Gaming Assistant Chat Logic
    fun sendAiMessage(userText: String) {
        if (userText.isBlank()) return

        val userMsg = ChatMessage(sender = "User", message = userText, isAi = false)
        _uiState.update {
            it.copy(
                aiChatMessages = it.aiChatMessages + userMsg,
                isAiTyping = true
            )
        }

        viewModelScope.launch {
            kotlinx.coroutines.delay(800)
            val replyText = generateAiStrategyResponse(userText)
            val aiMsg = ChatMessage(sender = "REENA AI", message = replyText, isAi = true)
            _uiState.update {
                it.copy(
                    aiChatMessages = it.aiChatMessages + aiMsg,
                    isAiTyping = false
                )
            }
        }
    }

    private fun generateAiStrategyResponse(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("vip") || q.contains("membership") || q.contains("₹10") || q.contains("theme") -> {
                "💎 VIP Elite Pass (₹10): Unlocks all 4 IMAX Premium Themes (Royal Gold, Matrix Emerald, Deep Crimson), VIP pilot badge, and 2x daily free faucet (+2,000 coins). All basic games remain 100% free with zero pay-per-round fees!"
            }
            q.contains("aviator") || q.contains("fly") || q.contains("altitude") || q.contains("eject") -> {
                "🚀 Aviator 3D Strategy: Bank early! The flight trajectory curve accelerates past Mach 2. Safe ejection between 1.8x and 2.8x yields a 74% win consistency. Keep an eye on particle turbulence—when red exhaust flickers, stall probability rises!"
            }
            q.contains("race") || q.contains("speed") || q.contains("drift") || q.contains("racer") -> {
                "🏎️ Cyber Velocity Pro Tip: Tap Turbo only on open straightaways when no incoming drone is in your current lane. Collecting glowing blue energy cores resets your lane dash cooldown and grants +50 bonus points!"
            }
            q.contains("puzzle") || q.contains("2048") || q.contains("matrix") -> {
                "🧩 Quantum Matrix Tip: Keep your highest chip locked in the bottom-left corner! Always swipe Left and Down as your primary vectors; only swipe Up when forced. This prevents low-value memory chips from fragmenting your core."
            }
            q.contains("adventure") || q.contains("dungeon") || q.contains("runner") -> {
                "🗡️ Neon Void 3D Guide: Use your EMP Shockwave when cornered between patrolling sentinels. Collect all 3 gold relics before entering the floor portal to maximize your virtual coin reward multiplier!"
            }
            q.contains("receipt") || q.contains("invoice") || q.contains("purchase") || q.contains("order") -> {
                "📜 In-App Purchase History: You can review all digital receipts, Google Play Order IDs, and status directly in the Purchase History tab under Profile or Admin Dashboard."
            }
            else -> {
                "⚡ REENA AI Analysis: I've scanned our 100+ game neural matrix. All basic games are 100% free. Check out our optional ₹10 VIP Pass for 4 custom themes and 2x faucets!"
            }
        }
    }

    // Admin Dashboard Controls
    fun toggleMaintenanceMode() {
        _uiState.update { state ->
            state.copy(adminMetrics = state.adminMetrics.copy(isMaintenanceMode = !state.adminMetrics.isMaintenanceMode))
        }
    }

    fun toggleDoubleXp() {
        _uiState.update { state ->
            state.copy(adminMetrics = state.adminMetrics.copy(isDoubleXpActive = !state.adminMetrics.isDoubleXpActive))
        }
    }

    fun toggleMegaBonus() {
        _uiState.update { state ->
            state.copy(adminMetrics = state.adminMetrics.copy(isMegaBonusActive = !state.adminMetrics.isMegaBonusActive))
        }
    }
}
