package com.example.model

data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    val icon: String,
    val isUnlocked: Boolean,
    val rewardCoins: Long
)

data class MatchHistoryItem(
    val id: String,
    val gameTitle: String,
    val category: GameCategory,
    val scoreOrMultiplier: String,
    val virtualCoinsEarned: Long,
    val timestamp: Long,
    val resultStatus: String // "Safe Bank", "Top 3 Finish", "Matrix Clear", "Floor Cleared"
)

data class UserProfile(
    val username: String = "CyberPilot_Reena",
    val title: String = "Neon Grandmaster",
    val level: Int = 18,
    val currentXp: Int = 3450,
    val maxXp: Int = 5000,
    val totalPlayCount: Int = 184,
    val totalCoinsWon: Long = 48250L,
    val highestAviatorMultiplier: Float = 14.82f,
    val achievements: List<Achievement> = emptyList(),
    val matchHistory: List<MatchHistoryItem> = emptyList()
)
