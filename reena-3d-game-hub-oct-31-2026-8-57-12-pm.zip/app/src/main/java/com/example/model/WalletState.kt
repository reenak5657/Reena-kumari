package com.example.model

enum class TransactionType {
    FAUCET_CLAIM,
    GAME_WIN,
    ACHIEVEMENT_BONUS,
    PRACTICE_FEE
}

data class WalletTransaction(
    val id: String,
    val title: String,
    val amount: Long,
    val timestamp: Long,
    val type: TransactionType
)

data class WalletState(
    val balance: Long = 5000L,
    val lastBonusTimestamp: Long = 0L,
    val transactions: List<WalletTransaction> = emptyList()
)
