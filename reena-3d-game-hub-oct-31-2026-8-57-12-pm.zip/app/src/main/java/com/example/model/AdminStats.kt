package com.example.model

data class AdminPlatformMetrics(
    val totalRegisteredUsers: Int = 154280,
    val liveActiveGamers: Int = 18432,
    val serverUptime: String = "99.98%",
    val serverLatencyMs: Int = 16,
    val totalDemoCoinsCirculating: Long = 428900000L,
    val totalVipPassesSold: Int = 1420,
    val totalRevenueInr: Int = 14200,
    val inAppBillingStatus: String = "Google Play In-App Billing Active",
    val isMaintenanceMode: Boolean = false,
    val isDoubleXpActive: Boolean = true,
    val isMegaBonusActive: Boolean = false,
    val featuredGameId: String = "aviator_supersonic",
    val categoryTraffic: Map<String, Int> = mapOf(
        "Aviator Arcade" to 38,
        "Cyber Racing" to 26,
        "Neon Puzzles" to 20,
        "3D Adventure" to 16
    )
)
