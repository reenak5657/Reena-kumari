package com.example.model

enum class GameCategory(val displayName: String, val iconName: String) {
    ALL("All Games", "Grid"),
    AVIATOR("Aviator Flight", "Flight"),
    RACING("Cyber Racing", "SportsMotorsports"),
    PUZZLE("Neon Puzzle", "Extension"),
    ADVENTURE("3D Adventure", "Explore"),
    SCI_FI("Sci-Fi Action", "Rocket"),
    STRATEGY("Strategy 3D", "Memory")
}

enum class DemoType {
    AVIATOR_FLIGHT,
    CYBER_RACER,
    QUANTUM_PUZZLE,
    NEON_RUNNER,
    NONE
}

data class GameItem(
    val id: String,
    val title: String,
    val category: GameCategory,
    val rating: Float,
    val playCount: String,
    val description: String,
    val tags: List<String>,
    val isPlayableDemo: Boolean = false,
    val demoType: DemoType = DemoType.NONE,
    val primaryColorHex: Long = 0xFF00E5FF,
    val secondaryColorHex: Long = 0xFFBD00FF,
    val badge: String? = null,
    val isFavorite: Boolean = false
)
