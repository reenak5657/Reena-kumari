package com.example.ui.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.abs
import kotlin.random.Random

@Composable
fun QuantumPuzzleGame(
    walletBalance: Long,
    onBack: () -> Unit,
    onRewardEarned: (coins: Long, score: String, summary: String) -> Unit
) {
    var board by remember {
        mutableStateOf(
            Array(4) { IntArray(4) }.apply {
                // Initialize with two random 2s
                val r1 = Random.nextInt(4); val c1 = Random.nextInt(4)
                var r2 = Random.nextInt(4); var c2 = Random.nextInt(4)
                while (r1 == r2 && c1 == c2) {
                    r2 = Random.nextInt(4); c2 = Random.nextInt(4)
                }
                this[r1][c1] = 2
                this[r2][c2] = 2
            }
        )
    }

    var score by remember { mutableIntStateOf(0) }
    var bestScore by remember { mutableIntStateOf(2480) }
    var previousBoard by remember { mutableStateOf<Array<IntArray>?>(null) }
    var previousScore by remember { mutableIntStateOf(0) }

    fun cloneBoard(src: Array<IntArray>): Array<IntArray> {
        return Array(4) { r -> src[r].clone() }
    }

    fun spawnTile(b: Array<IntArray>): Boolean {
        val emptySlots = mutableListOf<Pair<Int, Int>>()
        for (r in 0..3) {
            for (c in 0..3) {
                if (b[r][c] == 0) emptySlots.add(Pair(r, c))
            }
        }
        if (emptySlots.isEmpty()) return false
        val (r, c) = emptySlots[Random.nextInt(emptySlots.size)]
        b[r][c] = if (Random.nextFloat() < 0.9f) 2 else 4
        return true
    }

    fun moveLeft(b: Array<IntArray>): Pair<Boolean, Int> {
        var moved = false
        var pointsGained = 0
        for (r in 0..3) {
            val row = b[r].filter { it != 0 }.toMutableList()
            var i = 0
            while (i < row.size - 1) {
                if (row[i] == row[i + 1]) {
                    row[i] *= 2
                    pointsGained += row[i]
                    row.removeAt(i + 1)
                    moved = true
                }
                i++
            }
            while (row.size < 4) row.add(0)
            for (c in 0..3) {
                if (b[r][c] != row[c]) moved = true
                b[r][c] = row[c]
            }
        }
        return Pair(moved, pointsGained)
    }

    fun rotateClockwise(b: Array<IntArray>) {
        val n = 4
        for (i in 0 until n / 2) {
            for (j in i until n - i - 1) {
                val temp = b[i][j]
                b[i][j] = b[n - 1 - j][i]
                b[n - 1 - j][i] = b[n - 1 - i][n - 1 - j]
                b[n - 1 - i][n - 1 - j] = b[j][n - 1 - i]
                b[j][n - 1 - i] = temp
            }
        }
    }

    fun executeMove(direction: Int) { // 0: Left, 1: Up, 2: Right, 3: Down
        val currentCopy = cloneBoard(board)
        val rotations = when (direction) {
            0 -> 0 // Left
            1 -> 3 // Up: rotate 3 times, move left, rotate 1 time
            2 -> 2 // Right: rotate 2 times, move left, rotate 2 times
            3 -> 1 // Down: rotate 1 time, move left, rotate 3 times
            else -> 0
        }

        repeat(rotations) { rotateClockwise(currentCopy) }
        val (moved, points) = moveLeft(currentCopy)
        val remainingRotations = (4 - rotations) % 4
        repeat(remainingRotations) { rotateClockwise(currentCopy) }

        if (moved) {
            previousBoard = cloneBoard(board)
            previousScore = score
            spawnTile(currentCopy)
            board = currentCopy
            score += points
            if (score > bestScore) bestScore = score
            if (points >= 64) {
                val coins = (points / 4).toLong()
                onRewardEarned(coins, "$score pts", "Matrix Synthesis")
            }
        }
    }

    fun resetGame() {
        val newBoard = Array(4) { IntArray(4) }
        spawnTile(newBoard)
        spawnTile(newBoard)
        board = newBoard
        score = 0
        previousBoard = null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(CyberCard)
                    .testTag("puzzle_back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = NeonCyan)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "QUANTUM GRID 2048",
                    color = NeonGreen,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Holographic Neural Matrix Puzzle",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            IconButton(
                onClick = { resetGame() },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(CyberCard)
                    .testTag("puzzle_reset_button")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = NeonCyan)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Score & Controls Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    color = CyberCard,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                        Text("SCORE", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("$score", color = NeonCyan, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    }
                }

                Surface(
                    color = CyberCard,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                        Text("BEST", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("$bestScore", color = NeonGold, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            if (previousBoard != null) {
                Button(
                    onClick = {
                        previousBoard?.let {
                            board = cloneBoard(it)
                            score = previousScore
                            previousBoard = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Undo, contentDescription = null, tint = NeonPurpleGlow, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("UNDO", color = NeonPurpleGlow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 4x4 Grid Container with Swipe Gesture Detection
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .pointerInput(Unit) {
                    var totalDragX = 0f
                    var totalDragY = 0f
                    detectDragGestures(
                        onDragEnd = {
                            if (abs(totalDragX) > abs(totalDragY) && abs(totalDragX) > 60f) {
                                if (totalDragX > 0) executeMove(2) // Right
                                else executeMove(0) // Left
                            } else if (abs(totalDragY) > 60f) {
                                if (totalDragY > 0) executeMove(3) // Down
                                else executeMove(1) // Up
                            }
                            totalDragX = 0f
                            totalDragY = 0f
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            totalDragX += dragAmount.x
                            totalDragY += dragAmount.y
                        }
                    )
                },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CyberBlack),
            border = androidx.compose.foundation.BorderStroke(2.dp, CyberBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (r in 0..3) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (c in 0..3) {
                            val value = board[r][c]
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(getTileBackground(value))
                                    .border(
                                        width = 1.dp,
                                        color = getTileBorder(value),
                                        shape = RoundedCornerShape(10.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (value > 0) {
                                    Text(
                                        text = "$value",
                                        color = getTileTextColor(value),
                                        fontSize = if (value >= 1024) 18.sp else if (value >= 128) 22.sp else 26.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // D-Pad Touch Navigation for Accessibility & Precision Controls
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            IconButton(
                onClick = { executeMove(1) },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(CyberCard)
                    .border(1.dp, NeonCyan, CircleShape)
                    .testTag("puzzle_up_button")
            ) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Move Up", tint = NeonCyan, modifier = Modifier.size(32.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(0.7f),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { executeMove(0) },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(CyberCard)
                        .border(1.dp, NeonCyan, CircleShape)
                        .testTag("puzzle_left_button")
                ) {
                    Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Move Left", tint = NeonCyan, modifier = Modifier.size(32.dp))
                }

                Text(
                    text = "SWIPE OR TAP",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                IconButton(
                    onClick = { executeMove(2) },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(CyberCard)
                        .border(1.dp, NeonCyan, CircleShape)
                        .testTag("puzzle_right_button")
                ) {
                    Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Move Right", tint = NeonCyan, modifier = Modifier.size(32.dp))
                }
            }

            IconButton(
                onClick = { executeMove(3) },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(CyberCard)
                    .border(1.dp, NeonCyan, CircleShape)
                    .testTag("puzzle_down_button")
            ) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Move Down", tint = NeonCyan, modifier = Modifier.size(32.dp))
            }
        }
    }
}

private fun getTileBackground(value: Int): Brush {
    return when (value) {
        0 -> Brush.verticalGradient(listOf(Color(0xFF101625), Color(0xFF0C101A)))
        2 -> Brush.verticalGradient(listOf(Color(0xFF1E2A47), Color(0xFF141F36)))
        4 -> Brush.verticalGradient(listOf(Color(0xFF23365C), Color(0xFF1A2744)))
        8 -> Brush.verticalGradient(listOf(NeonCyanDim, Color(0xFF004D5A)))
        16 -> Brush.verticalGradient(listOf(Color(0xFF00897B), Color(0xFF004D40)))
        32 -> Brush.verticalGradient(listOf(NeonPurpleDim, Color(0xFF4A0072)))
        64 -> Brush.verticalGradient(listOf(Color(0xFF7B1FA2), Color(0xFF4A148C)))
        128 -> Brush.verticalGradient(listOf(NeonGold, Color(0xFFFF8F00)))
        256 -> Brush.verticalGradient(listOf(NeonGreen, Color(0xFF00B0FF)))
        512 -> Brush.verticalGradient(listOf(NeonRed, NeonPurple))
        1024 -> Brush.verticalGradient(listOf(NeonCyan, NeonPurpleGlow))
        2048 -> Brush.verticalGradient(listOf(NeonGold, NeonCyan, NeonPurple))
        else -> Brush.verticalGradient(listOf(NeonPurple, NeonCyan))
    }
}

private fun getTileBorder(value: Int): Color {
    return when (value) {
        0 -> CyberBorder
        2, 4 -> Color(0xFF334B75)
        8, 16 -> NeonCyan.copy(alpha = 0.6f)
        32, 64 -> NeonPurple.copy(alpha = 0.8f)
        128, 256 -> NeonGold
        512, 1024, 2048 -> NeonCyanGlow
        else -> NeonPurpleGlow
    }
}

private fun getTileTextColor(value: Int): Color {
    return when (value) {
        0 -> Color.Transparent
        2, 4 -> TextPrimary
        8, 16 -> NeonCyanGlow
        32, 64 -> NeonPurpleGlow
        128, 256 -> CyberBlack
        else -> TextPrimary
    }
}
