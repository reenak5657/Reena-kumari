package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Loyalty
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PremiumMembershipModal(
    isVipAlready: Boolean,
    onDismiss: () -> Unit,
    onPurchaseVipConfirmed: (adultConsent: Boolean) -> Unit
) {
    var isAdultConsentChecked by remember { mutableStateOf(false) }
    var isProcessingPayment by remember { mutableStateOf(false) }
    var showPaymentSuccess by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = { if (!isProcessingPayment) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .testTag("premium_membership_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = CyberBlack),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                Brush.horizontalGradient(listOf(NeonGold, NeonCyan, NeonPurple))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xFF332200),
                                    Color(0xFF191300),
                                    CyberBlack
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(32.dp)
                            .align(Alignment.TopEnd)
                            .clip(CircleShape)
                            .background(CyberBlack.copy(alpha = 0.6f))
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextPrimary, modifier = Modifier.size(16.dp))
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            shape = CircleShape,
                            color = NeonGold.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, NeonGold),
                            modifier = Modifier.size(60.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Diamond, contentDescription = null, tint = NeonGold, modifier = Modifier.size(34.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "VIP ELITE PASS",
                            color = NeonGold,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )

                        Text(
                            text = "₹10 ONE-TIME UNLOCK • ALL BASIC GAMES REMAIN FREE",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Features List
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "PREMIUM INCLUSIONS",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    VipFeatureRow(
                        icon = Icons.Default.ColorLens,
                        title = "4 Premium IMAX Themes",
                        description = "Instant access to Royal Gold, Matrix Emerald, Deep Crimson & Neon Violet themes."
                    )
                    VipFeatureRow(
                        icon = Icons.Default.Loyalty,
                        title = "VIP Gold Pilot Profile Badge",
                        description = "Exclusive 'VIP ELITE' verified emblem displayed on your pilot ID."
                    )
                    VipFeatureRow(
                        icon = Icons.Default.RocketLaunch,
                        title = "2x Daily Virtual Faucet",
                        description = "Claim +2,000 free virtual practice coins every day (instead of 1,000)."
                    )
                    VipFeatureRow(
                        icon = Icons.Default.VerifiedUser,
                        title = "100% Policy-Safe Entertainment",
                        description = "Zero pay-per-round fees, zero betting, no cash prizes, and no real-money gambling."
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Safe Payment Notice Card
                    Surface(
                        color = CyberCard,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "SECURE GOOGLE PLAY BILLING",
                                    color = NeonCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "We never request bank details, card numbers, or personal phone UPI. Payments are safely authorized via Google Play.",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (!isVipAlready) {
                        // Adult Authorization Gate
                        Surface(
                            color = CyberCard,
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isAdultConsentChecked) NeonGreen else CyberBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isAdultConsentChecked = !isAdultConsentChecked }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isAdultConsentChecked,
                                    onCheckedChange = { isAdultConsentChecked = it },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = NeonGreen,
                                        uncheckedColor = TextMuted,
                                        checkmarkColor = CyberBlack
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "I confirm that I am 18+ years of age or an authorized adult account-holder approving this ₹10 purchase.",
                                    color = if (isAdultConsentChecked) TextPrimary else TextSecondary,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Checkout Action
                        if (isProcessingPayment) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(color = NeonGold, modifier = Modifier.size(26.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("Connecting to Google Play Billing...", color = TextSecondary, fontSize = 12.sp)
                            }
                        } else {
                            Button(
                                onClick = {
                                    if (isAdultConsentChecked) {
                                        isProcessingPayment = true
                                        scope.launch {
                                            delay(1200) // Simulate official BillingClient bottom sheet
                                            isProcessingPayment = false
                                            showPaymentSuccess = true
                                            onPurchaseVipConfirmed(true)
                                            delay(1000)
                                            onDismiss()
                                        }
                                    }
                                },
                                enabled = isAdultConsentChecked,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("pay_ten_rupees_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonGold,
                                    disabledContainerColor = CyberCard
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CreditCard, contentDescription = null, tint = if (isAdultConsentChecked) CyberBlack else TextMuted)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "UNLOCK VIP PASS (₹10)",
                                        color = if (isAdultConsentChecked) CyberBlack else TextMuted,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    } else {
                        // Already VIP Active
                        Surface(
                            color = NeonGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = NeonGreen)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "VIP Elite Pass is Active on this Device! You have unlocked all 4 themes and bonuses.",
                                    color = NeonGreen,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VipFeatureRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            shape = CircleShape,
            color = NeonGold.copy(alpha = 0.15f),
            modifier = Modifier.size(32.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = NeonGold, modifier = Modifier.size(16.dp))
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(title, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(description, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}
