package com.example.ui.games

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameCategory
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

enum class FlightStatus {
    IDLE,
    FLYING,
    CRASHED,
    BANKED
}

@Composable
fun AviatorArcadeGame(
    walletBalance: Long,
    onBack: () -> Unit,
    onRewardEarned: (coins: Long, multiplier: Float, summary: String) -> Unit,
    onDeductCoins: (coins: Long) -> Boolean
) {
    val context = LocalContext.current
    var flightStatus by remember { mutableStateOf(FlightStatus.IDLE) }
    var currentMultiplier by remember { mutableFloatStateOf(1.00f) }
    var altitudeMeters by remember { mutableLongStateOf(1000L) }
    var selectedDemoCoins by remember { mutableLongStateOf(5L) }
    var crashPoint by remember { mutableFloatStateOf(2.50f) }
    var bankedMultiplier by remember { mutableFloatStateOf(0.00f) }
    val historyMultipliers = remember { mutableStateListOf(2.45f, 1.80f, 6.12f, 1.34f, 3.75f, 12.20f) }

    val starOffset = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        starOffset.animateTo(
            targetValue = 1000f,
            animationSpec = infiniteRepeatable(
                animation = tween(15000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            )
        )
    }

    // Vibrator helper
    fun triggerVibration(durationMs: Long) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    // Main flight loop
    LaunchedEffect(flightStatus) {
        if (flightStatus == FlightStatus.FLYING) {
            currentMultiplier = 1.00f
            altitudeMeters = 1000L

            // Weighted crash point between 1.15x and 18.0x
            val roll = Random.nextFloat()
            crashPoint = when {
                roll < 0.15f -> 1.10f + Random.nextFloat() * 0.4f
                roll < 0.55f -> 1.50f + Random.nextFloat() * 2.0f
                roll < 0.85f -> 3.50f + Random.nextFloat() * 4.5f
                else -> 8.0f + Random.nextFloat() * 10.0f
            }

            while (flightStatus == FlightStatus.FLYING) {
                delay(60)
                // Accelerating curve
                val step = 0.02f + (currentMultiplier * 0.008f)
                currentMultiplier += step
                altitudeMeters += (step * 850).toLong()

                if (currentMultiplier >= crashPoint) {
                    flightStatus = FlightStatus.CRASHED
                    triggerVibration(250)
                    historyMultipliers.add(0, String.format("%.2f", crashPoint).toFloat())
                    if (historyMultipliers.size > 10) historyMultipliers.removeLast()
                    break
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .padding(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(CyberCard)
                    .testTag("aviator_back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = NeonCyan)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "AVIATOR 3D",
                        color = NeonCyan,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = NeonPurple.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple)
                    ) {
                        Text(
                            text = "ARCADE DEMO",
                            color = NeonPurpleGlow,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = "Virtual Points Flight Simulator • Non-Betting",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            // Virtual Wallet Chip
            Surface(
                color = CyberCard,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonGold.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🪙", fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$walletBalance",
                        color = NeonGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // History Multiplier Strip
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(historyMultipliers) { mult ->
                val pillColor = if (mult >= 2.0f) NeonPurple else NeonCyanDim
                Surface(
                    color = CyberCard,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, pillColor.copy(alpha = 0.7f))
                ) {
                    Text(
                        text = "${String.format("%.2f", mult)}x",
                        color = if (mult >= 3.0f) NeonGold else TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Flight Display Screen (IMAX Canvas)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CyberBlack),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberBorder)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Interactive 3D Flight Canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Grid lines (Cyber radar)
                    for (i in 1..4) {
                        val y = h * (i / 5f)
                        drawLine(
                            color = Color(0xFF162035),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                    }

                    // Dynamic Flight Trajectory Curve
                    val progress = when (flightStatus) {
                        FlightStatus.FLYING -> ((currentMultiplier - 1.00f) / 6.0f).coerceIn(0.05f, 0.95f)
                        FlightStatus.CRASHED -> 0.95f
                        FlightStatus.BANKED -> ((bankedMultiplier - 1.00f) / 6.0f).coerceIn(0.05f, 0.95f)
                        FlightStatus.IDLE -> 0.05f
                    }

                    val planeX = w * (0.15f + progress * 0.75f)
                    val planeY = h * (0.85f - progress * 0.65f)

                    val flightPath = Path().apply {
                        moveTo(w * 0.1f, h * 0.88f)
                        quadraticTo(
                            w * 0.35f, h * 0.85f,
                            planeX, planeY
                        )
                    }

                    // Glowing trajectory fill gradient
                    val fillPath = Path().apply {
                        addPath(flightPath)
                        lineTo(planeX, h * 0.95f)
                        lineTo(w * 0.1f, h * 0.95f)
                        close()
                    }

                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                (if (flightStatus == FlightStatus.CRASHED) NeonRed else NeonCyan).copy(alpha = 0.35f),
                                Color.Transparent
                            )
                        )
                    )

                    // Trajectory Line
                    drawPath(
                        path = flightPath,
                        color = if (flightStatus == FlightStatus.CRASHED) NeonRed else NeonCyan,
                        style = Stroke(width = 5f)
                    )

                    // Draw Supersonic Jet at (planeX, planeY)
                    if (flightStatus != FlightStatus.CRASHED) {
                        // Jet Thrust Particles
                        drawCircle(
                            brush = Brush.radialGradient(listOf(NeonCyanGlow, Color.Transparent)),
                            radius = 28f,
                            center = Offset(planeX - 18f, planeY + 8f)
                        )
                        // Jet Body
                        val jetPath = Path().apply {
                            moveTo(planeX + 22f, planeY - 10f) // Nose
                            lineTo(planeX - 16f, planeY + 12f) // Tail left
                            lineTo(planeX - 8f, planeY - 2f)   // Center engine
                            lineTo(planeX - 22f, planeY - 4f)  // Wing back
                            close()
                        }
                        drawPath(jetPath, color = Color.White)
                        drawCircle(
                            color = NeonPurpleGlow,
                            radius = 4f,
                            center = Offset(planeX + 4f, planeY - 4f)
                        )
                    } else {
                        // Burnout Blast Marker
                        drawCircle(
                            brush = Brush.radialGradient(listOf(NeonRed, NeonGold, Color.Transparent)),
                            radius = 45f,
                            center = Offset(planeX, planeY)
                        )
                    }
                }

                // Center Altitude & Multiplier Overlay
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when (flightStatus) {
                        FlightStatus.FLYING -> {
                            Text(
                                text = "${String.format("%.2f", currentMultiplier)}x",
                                color = if (currentMultiplier >= 3f) NeonGold else NeonCyan,
                                fontSize = 54.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "ALTITUDE: ${altitudeMeters}m",
                                    color = TextSecondary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "MACH ${(currentMultiplier * 1.4f).let { String.format("%.1f", it) }}",
                                    color = NeonPurpleGlow,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        FlightStatus.BANKED -> {
                            Text(
                                text = "SAFE LANDING!",
                                color = NeonGreen,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Landed at ${String.format("%.2f", bankedMultiplier)}x",
                                color = TextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "+${(selectedDemoCoins * bankedMultiplier).toLong()} Virtual Demo Coins Banked!",
                                color = NeonGold,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        FlightStatus.CRASHED -> {
                            Text(
                                text = "SUPERSONIC BURNOUT",
                                color = NeonRed,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Stalled at ${String.format("%.2f", crashPoint)}x",
                                color = TextSecondary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Craft safely returned to hangar. Try another launch!",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                        FlightStatus.IDLE -> {
                            Icon(
                                Icons.Default.RocketLaunch,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(52.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "READY FOR STRATOSPHERIC ASCENT",
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Select demo stake and launch flight. Bank before burnout!",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Virtual Entry Stake / Tier Selector (Starting from 5 Coins)
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "VIRTUAL ENTRY TIER:",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Selected: $selectedDemoCoins Virtual Coins",
                    color = NeonGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    Pair(5L, "5 Bronze"),
                    Pair(50L, "50 Silver"),
                    Pair(250L, "250 Gold"),
                    Pair(1000L, "1K Elite")
                ).forEach { (coins, label) ->
                    val isSelected = selectedDemoCoins == coins
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(enabled = flightStatus != FlightStatus.FLYING) {
                                selectedDemoCoins = coins
                            },
                        color = if (isSelected) NeonCyanDim else CyberCard,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) NeonCyan else CyberBorder
                        )
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) TextPrimary else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Action Button
        when (flightStatus) {
            FlightStatus.FLYING -> {
                Button(
                    onClick = {
                        flightStatus = FlightStatus.BANKED
                        bankedMultiplier = currentMultiplier
                        val wonCoins = (selectedDemoCoins * currentMultiplier).toLong()
                        onRewardEarned(wonCoins, currentMultiplier, "Aviator 3D Landing")
                        triggerVibration(100)
                        historyMultipliers.add(0, String.format("%.2f", currentMultiplier).toFloat())
                        if (historyMultipliers.size > 10) historyMultipliers.removeLast()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("aviator_eject_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = CyberBlack)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SAFE LANDING & BANK (+${(selectedDemoCoins * currentMultiplier).toLong()} COINS)",
                            color = CyberBlack,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                    }
                }
            }
            else -> {
                Button(
                    onClick = {
                        if (walletBalance >= selectedDemoCoins) {
                            if (onDeductCoins(selectedDemoCoins)) {
                                flightStatus = FlightStatus.FLYING
                                triggerVibration(50)
                            }
                        } else {
                            // Automatically provide demo refill if empty
                            onRewardEarned(500L, 1.0f, "Auto Demo Faucet Refill")
                            flightStatus = FlightStatus.FLYING
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("aviator_launch_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = CyberBlack)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (flightStatus == FlightStatus.IDLE) "LAUNCH SUPERSONIC FLIGHT ($selectedDemoCoins PTS)" else "PLAY NEXT FLIGHT ($selectedDemoCoins PTS)",
                            color = CyberBlack,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Safety & Policy Disclaimer
        Surface(
            color = CyberCard.copy(alpha = 0.6f),
            shape = RoundedCornerShape(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "100% Free Virtual Points Arcade. No real deposits, wagering, betting, or cash withdrawals.",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }
    }
}
