package com.example.ui.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanGlow
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleGlow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlin.random.Random

data class SentinelDrone(
    var x: Int,
    var y: Int,
    var dx: Int,
    var dy: Int
)

data class CyberRelic(
    val x: Int,
    val y: Int,
    var collected: Boolean = false
)

@Composable
fun NeonRunnerGame(
    walletBalance: Long,
    onBack: () -> Unit,
    onRewardEarned: (coins: Long, score: String, summary: String) -> Unit
) {
    val gridSize = 7
    var playerX by remember { mutableIntStateOf(1) }
    var playerY by remember { mutableIntStateOf(1) }
    var currentFloor by remember { mutableIntStateOf(1) }
    var playerHp by remember { mutableIntStateOf(3) }
    var relicsCollected by remember { mutableIntStateOf(0) }
    var isShieldActive by remember { mutableStateOf(false) }
    var empCharges by remember { mutableIntStateOf(2) }
    var isGameOver by remember { mutableStateOf(false) }

    val exitPortal = remember(currentFloor) { Pair(5, 5) }
    val relics = remember(currentFloor) {
        mutableStateListOf(
            CyberRelic(2, 4),
            CyberRelic(4, 2),
            CyberRelic(5, 1)
        )
    }

    val drones = remember(currentFloor) {
        mutableStateListOf(
            SentinelDrone(3, 1, 0, 1),
            SentinelDrone(1, 3, 1, 0)
        )
    }

    // Patrolling drones movement loop
    LaunchedEffect(currentFloor, isGameOver) {
        while (!isGameOver) {
            delay(500)
            drones.forEach { drone ->
                val nextX = drone.x + drone.dx
                val nextY = drone.y + drone.dy
                if (nextX in 1 until gridSize - 1 && nextY in 1 until gridSize - 1) {
                    drone.x = nextX
                    drone.y = nextY
                } else {
                    drone.dx = -drone.dx
                    drone.dy = -drone.dy
                }

                // Check collision with player
                if (drone.x == playerX && drone.y == playerY) {
                    if (isShieldActive) {
                        isShieldActive = false
                    } else {
                        playerHp -= 1
                        if (playerHp <= 0) {
                            isGameOver = true
                        }
                    }
                }
            }
        }
    }

    fun movePlayer(dx: Int, dy: Int) {
        if (isGameOver) return
        val newX = (playerX + dx).coerceIn(1, gridSize - 2)
        val newY = (playerY + dy).coerceIn(1, gridSize - 2)
        playerX = newX
        playerY = newY

        // Check relic collection
        relics.forEach { relic ->
            if (!relic.collected && relic.x == playerX && relic.y == playerY) {
                relic.collected = true
                relicsCollected += 1
            }
        }

        // Check Exit Portal
        if (playerX == exitPortal.first && playerY == exitPortal.second) {
            val floorBonus = (currentFloor * 150L) + (relicsCollected * 50L)
            onRewardEarned(floorBonus, "Floor $currentFloor Cleared", "3D Dungeon Floor Win")
            currentFloor += 1
            playerX = 1
            playerY = 1
            empCharges += 1
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .padding(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(CyberCard)
                    .testTag("adventure_back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = NeonCyan)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "NEON VOID 3D",
                    color = NeonPurpleGlow,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Subterranean Cyber Dungeon • Floor $currentFloor",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            IconButton(
                onClick = {
                    currentFloor = 1
                    playerHp = 3
                    relicsCollected = 0
                    playerX = 1
                    playerY = 1
                    empCharges = 2
                    isGameOver = false
                },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(CyberCard)
                    .testTag("adventure_reset_button")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = NeonCyan)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Status HUD
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                color = CyberCard,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("HP: ", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    repeat(3) { i ->
                        Text(
                            text = if (i < playerHp) "❤️" else "🖤",
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 1.dp)
                        )
                    }
                }
            }

            Surface(
                color = CyberCard,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("💎 RELICS: ", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("$relicsCollected", color = NeonGold, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 3D Isometric Cyber Dungeon Canvas
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CyberBlack),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberBorder)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val tileW = (w * 0.85f) / gridSize
                    val tileH = (h * 0.85f) / gridSize
                    val startX = (w - (tileW * gridSize)) / 2
                    val startY = (h - (tileH * gridSize)) / 2

                    // Grid floor tiles
                    for (gx in 0 until gridSize) {
                        for (gy in 0 until gridSize) {
                            val tx = startX + gx * tileW
                            val ty = startY + gy * tileH
                            val isWall = gx == 0 || gx == gridSize - 1 || gy == 0 || gy == gridSize - 1
                            val tileColor = if (isWall) Color(0xFF13192B) else Color(0xFF0F1524)
                            val borderColor = if (isWall) CyberBorder else Color(0xFF1A233A)

                            drawRect(
                                color = tileColor,
                                topLeft = Offset(tx, ty),
                                size = Size(tileW - 2f, tileH - 2f)
                            )
                            drawRect(
                                color = borderColor,
                                topLeft = Offset(tx, ty),
                                size = Size(tileW - 2f, tileH - 2f),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(1f)
                            )
                        }
                    }

                    // Exit Portal (green/gold pulsating warp)
                    val pTx = startX + exitPortal.first * tileW + tileW / 2
                    val pTy = startY + exitPortal.second * tileH + tileH / 2
                    drawCircle(
                        brush = Brush.radialGradient(listOf(NeonGreen, NeonCyan, Color.Transparent)),
                        radius = tileW * 0.45f,
                        center = Offset(pTx, pTy)
                    )

                    // Relics
                    relics.forEach { relic ->
                        if (!relic.collected) {
                            val rX = startX + relic.x * tileW + tileW / 2
                            val rY = startY + relic.y * tileH + tileH / 2
                            drawCircle(
                                brush = Brush.radialGradient(listOf(NeonGold, Color.Transparent)),
                                radius = tileW * 0.35f,
                                center = Offset(rX, rY)
                            )
                        }
                    }

                    // Sentinel Drones
                    drones.forEach { drone ->
                        val dX = startX + drone.x * tileW + tileW / 2
                        val dY = startY + drone.y * tileH + tileH / 2
                        drawCircle(
                            brush = Brush.radialGradient(listOf(NeonRed, Color.Transparent)),
                            radius = tileW * 0.38f,
                            center = Offset(dX, dY)
                        )
                    }

                    // Player Hero
                    val plX = startX + playerX * tileW + tileW / 2
                    val plY = startY + playerY * tileH + tileH / 2

                    if (isShieldActive) {
                        drawCircle(
                            color = NeonCyanGlow.copy(alpha = 0.4f),
                            radius = tileW * 0.55f,
                            center = Offset(plX, plY)
                        )
                    }

                    drawCircle(
                        brush = Brush.radialGradient(listOf(NeonCyan, NeonPurpleGlow)),
                        radius = tileW * 0.36f,
                        center = Offset(plX, plY)
                    )
                }

                if (isGameOver) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(CyberBlack.copy(alpha = 0.85f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("MISSION FAILED", color = NeonRed, fontSize = 24.sp, fontWeight = FontWeight.Black)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Cyber drone eliminated shield core.", color = TextSecondary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = {
                                    currentFloor = 1
                                    playerHp = 3
                                    relicsCollected = 0
                                    playerX = 1
                                    playerY = 1
                                    empCharges = 2
                                    isGameOver = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                            ) {
                                Text("RETRY DUNGEON", color = CyberBlack, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Inventory Powers & D-Pad Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Power-up Buttons
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (!isShieldActive) isShieldActive = true
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isShieldActive) NeonCyan else CyberCard
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = if (isShieldActive) CyberBlack else NeonCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isShieldActive) "SHIELD ON" else "ACTIVATE SHIELD", color = if (isShieldActive) CyberBlack else TextPrimary, fontSize = 11.sp)
                }

                Button(
                    onClick = {
                        if (empCharges > 0) {
                            empCharges -= 1
                            drones.forEach { drone ->
                                drone.dx = 0
                                drone.dy = 0
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, tint = NeonPurpleGlow, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("EMP BLAST ($empCharges)", color = NeonPurpleGlow, fontSize = 11.sp)
                }
            }

            // D-Pad Movement
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = { movePlayer(0, -1) },
                    modifier = Modifier.size(46.dp).clip(CircleShape).background(CyberCard).border(1.dp, NeonCyan, CircleShape)
                ) {
                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up", tint = NeonCyan)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    IconButton(
                        onClick = { movePlayer(-1, 0) },
                        modifier = Modifier.size(46.dp).clip(CircleShape).background(CyberCard).border(1.dp, NeonCyan, CircleShape)
                    ) {
                        Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Left", tint = NeonCyan)
                    }
                    IconButton(
                        onClick = { movePlayer(1, 0) },
                        modifier = Modifier.size(46.dp).clip(CircleShape).background(CyberCard).border(1.dp, NeonCyan, CircleShape)
                    ) {
                        Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Right", tint = NeonCyan)
                    }
                }
                IconButton(
                    onClick = { movePlayer(0, 1) },
                    modifier = Modifier.size(46.dp).clip(CircleShape).background(CyberCard).border(1.dp, NeonCyan, CircleShape)
                ) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down", tint = NeonCyan)
                }
            }
        }
    }
}
