package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// IMAX Cinematic Dark Palette
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanGlow = Color(0xFF18FFFF)
val NeonCyanDim = Color(0xFF00838F)

val NeonPurple = Color(0xFFBD00FF)
val NeonPurpleGlow = Color(0xFFE040FB)
val NeonPurpleDim = Color(0xFF6A0080)

val CyberBlack = Color(0xFF07090E)
val CyberDarkBg = Color(0xFF0B0F19)
val CyberSurface = Color(0xFF111726)
val CyberCard = Color(0xFF161F33)
val CyberCardElevated = Color(0xFF1C2740)
val CyberBorder = Color(0xFF273554)
val CyberBorderGlowing = Color(0xFF3B4E7A)

val NeonGold = Color(0xFFFFB300)
val NeonGoldGlow = Color(0xFFFFD54F)

val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF1744)

val TextPrimary = Color(0xFFF3F6FD)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
