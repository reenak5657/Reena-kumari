package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.ToggleOn
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanDim
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleGlow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.GameHubUiState

@Composable
fun AdminDashboardScreen(
    state: GameHubUiState,
    onBack: () -> Unit,
    onToggleMaintenance: () -> Unit,
    onToggleDoubleXp: () -> Unit,
    onToggleMegaBonus: () -> Unit
) {
    val metrics = state.adminMetrics

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg),
        contentPadding = PaddingValues(16.dp)
    ) {
        // Admin Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(CyberCard)
                        .testTag("admin_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = NeonCyan)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ADMIN COMMAND CENTER",
                        color = NeonCyan,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Real-time Platform Telemetry & Controls",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }

                Surface(
                    color = NeonGreen.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen)
                ) {
                    Text(
                        text = "ROOT SECURE",
                        color = NeonGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }

        // Live Server Vitals Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberBlack),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "INFRASTRUCTURE VITALS",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AdminVitalsTile(
                            title = "ONLINE PLAYERS",
                            value = "${metrics.liveActiveGamers}",
                            icon = Icons.Default.Wifi,
                            color = NeonGreen,
                            modifier = Modifier.weight(1f)
                        )
                        AdminVitalsTile(
                            title = "SERVER UPTIME",
                            value = metrics.serverUptime,
                            icon = Icons.Default.Dns,
                            color = NeonCyan,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AdminVitalsTile(
                            title = "LATENCY (API)",
                            value = "${metrics.serverLatencyMs}ms",
                            icon = Icons.Default.Speed,
                            color = NeonPurpleGlow,
                            modifier = Modifier.weight(1f)
                        )
                        AdminVitalsTile(
                            title = "TOTAL ACCOUNTS",
                            value = "${metrics.totalRegisteredUsers}",
                            icon = Icons.Default.AdminPanelSettings,
                            color = NeonGold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }

        // In-App Digital Sales & VIP Membership Dashboard
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberBlack),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, NeonGold.copy(alpha = 0.8f))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = NeonGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "IN-APP SALES & VIP PASSES",
                                color = NeonGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }
                        Surface(
                            color = NeonGreen.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "BILLING ACTIVE",
                                color = NeonGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AdminVitalsTile(
                            title = "GROSS DIGITAL SALES",
                            value = "₹${metrics.totalRevenueInr}",
                            icon = Icons.Default.Payments,
                            color = NeonGold,
                            modifier = Modifier.weight(1f)
                        )
                        AdminVitalsTile(
                            title = "VIP PASSES (₹10)",
                            value = "${metrics.totalVipPassesSold}",
                            icon = Icons.Default.Diamond,
                            color = NeonCyan,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AdminVitalsTile(
                            title = "CONVERSION RATE",
                            value = "4.8%",
                            icon = Icons.Default.TrendingUp,
                            color = NeonGreen,
                            modifier = Modifier.weight(1f)
                        )
                        AdminVitalsTile(
                            title = "GATEWAY PROVIDER",
                            value = "Google Play",
                            icon = Icons.Default.Security,
                            color = NeonPurpleGlow,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = CyberCard,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "100% Google Play Billing Compliant. Adult authorization gate enforced. No direct bank details or UPI stored.",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }

        // Game Traffic Heatmap / Distribution
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "GAME CATEGORY TRAFFIC SHARE",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    metrics.categoryTraffic.forEach { (category, percentage) ->
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(category, color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("$percentage%", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { percentage / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = when (category) {
                                    "Aviator Arcade" -> NeonCyan
                                    "Cyber Racing" -> NeonRed
                                    "Neon Puzzles" -> NeonGreen
                                    else -> NeonPurple
                                },
                                trackColor = CyberBlack
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }

        // Platform Toggles & Security Controls
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "LIVE PLATFORM CONTROLS",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Toggle 1: Double XP Weekend
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Double EXP Event Mode", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Grants 2x pilot rank XP on all mini-game completions", color = TextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = metrics.isDoubleXpActive,
                            onCheckedChange = { onToggleDoubleXp() },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberBlack, checkedTrackColor = NeonCyan)
                        )
                    }

                    // Toggle 2: Mega Faucet Bonus
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Mega Faucet Multiplier", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Increases daily practice demo bonus from 1,000 to 2,500", color = TextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = metrics.isMegaBonusActive,
                            onCheckedChange = { onToggleMegaBonus() },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberBlack, checkedTrackColor = NeonGold)
                        )
                    }

                    // Toggle 3: Maintenance Mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Emergency Maintenance Shield", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Limits new matchmaking sessions for cluster upgrades", color = TextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = metrics.isMaintenanceMode,
                            onCheckedChange = { onToggleMaintenance() },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberBlack, checkedTrackColor = NeonRed)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminVitalsTile(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = CyberCard,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = color.copy(alpha = 0.15f),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}
