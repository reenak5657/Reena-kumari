package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.data.local.AppThemeMode

fun getReenaColorScheme(themeMode: AppThemeMode): ColorScheme {
    val (primaryColor, primaryGlow, secondaryColor, secondaryGlow) = when (themeMode) {
        AppThemeMode.DEFAULT_IMAX -> Quadruple(NeonCyan, NeonCyanGlow, NeonPurple, NeonPurpleGlow)
        AppThemeMode.ROYAL_GOLD -> Quadruple(NeonGold, NeonGoldGlow, Color(0xFFFF8F00), Color(0xFFFFE082))
        AppThemeMode.MATRIX_EMERALD -> Quadruple(NeonGreen, Color(0xFF69F0AE), NeonCyan, NeonCyanGlow)
        AppThemeMode.DEEP_CRIMSON -> Quadruple(NeonRed, Color(0xFFFF5252), NeonPurple, NeonPurpleGlow)
    }

    return darkColorScheme(
        primary = primaryColor,
        onPrimary = CyberBlack,
        primaryContainer = primaryColor.copy(alpha = 0.3f),
        onPrimaryContainer = primaryGlow,

        secondary = secondaryColor,
        onSecondary = CyberBlack,
        secondaryContainer = secondaryColor.copy(alpha = 0.3f),
        onSecondaryContainer = secondaryGlow,

        tertiary = NeonGold,
        onTertiary = CyberBlack,
        tertiaryContainer = CyberCardElevated,
        onTertiaryContainer = NeonGoldGlow,

        background = CyberDarkBg,
        onBackground = TextPrimary,

        surface = CyberSurface,
        onSurface = TextPrimary,
        surfaceVariant = CyberCard,
        onSurfaceVariant = TextSecondary,

        outline = CyberBorder,
        outlineVariant = CyberBorderGlowing,

        error = NeonRed,
        onError = TextPrimary
    )
}

data class Quadruple<T>(val first: T, val second: T, val third: T, val fourth: T)

@Composable
fun MyApplicationTheme(
    themeMode: AppThemeMode = AppThemeMode.DEFAULT_IMAX,
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = CyberDarkBg.toArgb()
                window.navigationBarColor = CyberDarkBg.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = getReenaColorScheme(themeMode),
        typography = Typography,
        content = content
    )
}
