package com.example.ui.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.random.Random

data class HighwayObstacle(
    val id: Long,
    val lane: Int, // 0 = Left, 1 = Center, 2 = Right
    var yProgress: Float, // 0.0 (horizon) to 1.0 (bottom)
    val isPowerup: Boolean = false
)

@Composable
fun CyberRacerGame(
    walletBalance: Long,
    onBack: () -> Unit,
    onRewardEarned: (coins: Long, score: String, summary: String) -> Unit
) {
    var playerLane by remember { mutableIntStateOf(1) } // 0, 1, 2
    var score by remember { mutableIntStateOf(0) }
    var speedKmH by remember { mutableIntStateOf(160) }
    var isTurboActive by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }
    var shieldsRemaining by remember { mutableIntStateOf(2) }

    val obstacles = remember { mutableStateListOf<HighwayObstacle>() }
    var nextSpawnTick by remember { mutableIntStateOf(0) }
    var roadDashOffset by remember { mutableFloatStateOf(0f) }

    // Game loop
    LaunchedEffect(isGameOver, isTurboActive) {
        if (!isGameOver) {
            while (!isGameOver) {
                delay(30)
                roadDashOffset = (roadDashOffset + 0.06f) % 1f
                val speedFactor = if (isTurboActive) 1.8f else 1.0f
                speedKmH = if (isTurboActive) 320 else (160 + (score / 15)).coerceAtMost(260)
                score += if (isTurboActive) 3 else 1

                // Move obstacles
                val iterator = obstacles.listIterator()
                while (iterator.hasNext()) {
                    val obs = iterator.next()
                    obs.yProgress += (0.018f * speedFactor)

                    // Collision check when obstacle is near player (yProgress between 0.82 and 0.96)
                    if (obs.yProgress in 0.82f..0.96f && obs.lane == playerLane) {
                        if (obs.isPowerup) {
                            score += 50
                            iterator.remove()
                        } else {
                            if (shieldsRemaining > 0) {
                                shieldsRemaining -= 1
                                iterator.remove()
                            } else {
                                isGameOver = true
                                val virtualCoins = (score / 8).toLong().coerceAtLeast(50L)
                                onRewardEarned(virtualCoins, "$score pts", "Cyber Racer Finish")
                                break
                            }
                        }
                    } else if (obs.yProgress > 1.15f) {
                        iterator.remove()
                    }
                }

                // Spawn new obstacles
                nextSpawnTick++
                val spawnInterval = if (isTurboActive) 28 else 42
                if (nextSpawnTick >= spawnInterval) {
                    nextSpawnTick = 0
                    val lane = Random.nextInt(3)
                    val isBonus = Random.nextFloat() < 0.35f
                    obstacles.add(
                        HighwayObstacle(
                            id = System.nanoTime(),
                            lane = lane,
                            yProgress = 0.05f,
                            isPowerup = isBonus
                        )
                    )
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .padding(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(CyberCard)
                    .testTag("racer_back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = NeonCyan)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "CYBER VELOCITY 3D",
                    color = NeonRed,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Neon Highway 2099 • 3D Turbo Racer",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            // Shield status
            Surface(
                color = CyberCard,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🛡️", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$shieldsRemaining",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // HUD Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                color = CyberCard,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Text("SCORE", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("$score PTS", color = NeonCyan, fontSize = 16.sp, fontWeight = FontWeight.Black)
                }
            }

            Surface(
                color = CyberCard,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Text("SPEED", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "$speedKmH KM/H",
                        color = if (isTurboActive) NeonRed else NeonGreen,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3D Perspective Racing Highway
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CyberBlack),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberBorder)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val horizonY = h * 0.22f

                    // Horizon sky glow
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF0F0826), Color(0xFF1B0F40)),
                            startY = 0f,
                            endY = horizonY
                        ),
                        topLeft = Offset(0f, 0f),
                        size = Size(w, horizonY)
                    )

                    // Distant glowing cyber skyline
                    val skylineX = listOf(0.1f, 0.25f, 0.4f, 0.6f, 0.75f, 0.9f)
                    skylineX.forEachIndexed { i, factor ->
                        val bWidth = w * 0.12f
                        val bHeight = horizonY * (0.4f + (i % 3) * 0.2f)
                        drawRect(
                            color = Color(0xFF141935),
                            topLeft = Offset(w * factor - bWidth / 2, horizonY - bHeight),
                            size = Size(bWidth, bHeight)
                        )
                    }

                    // Road Surface Trapezoid (Perspective)
                    val roadTopLeft = Offset(w * 0.35f, horizonY)
                    val roadTopRight = Offset(w * 0.65f, horizonY)
                    val roadBottomLeft = Offset(w * 0.05f, h)
                    val roadBottomRight = Offset(w * 0.95f, h)

                    val roadPath = Path().apply {
                        moveTo(roadTopLeft.x, roadTopLeft.y)
                        lineTo(roadTopRight.x, roadTopRight.y)
                        lineTo(roadBottomRight.x, roadBottomRight.y)
                        lineTo(roadBottomLeft.x, roadBottomLeft.y)
                        close()
                    }

                    drawPath(
                        path = roadPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF0E1220), Color(0xFF161E36)),
                            startY = horizonY,
                            endY = h
                        )
                    )

                    // Road Border Neon Glow Lines
                    drawLine(NeonCyan, roadTopLeft, roadBottomLeft, strokeWidth = 5f)
                    drawLine(NeonPurple, roadTopRight, roadBottomRight, strokeWidth = 5f)

                    // Lane Dividers (2 inner dividers dividing into 3 lanes)
                    for (laneDiv in 1..2) {
                        val fraction = laneDiv / 3f
                        val topX = roadTopLeft.x + (roadTopRight.x - roadTopLeft.x) * fraction
                        val botX = roadBottomLeft.x + (roadBottomRight.x - roadBottomLeft.x) * fraction

                        // Draw moving dashed lines
                        for (d in 0..10) {
                            val t1 = (d / 10f + roadDashOffset * 0.1f).coerceIn(0f, 1f)
                            val t2 = (t1 + 0.04f).coerceIn(0f, 1f)

                            val startPt = Offset(topX + (botX - topX) * t1, horizonY + (h - horizonY) * t1)
                            val endPt = Offset(topX + (botX - topX) * t2, horizonY + (h - horizonY) * t2)

                            drawLine(
                                color = NeonCyanGlow.copy(alpha = 0.6f),
                                start = startPt,
                                end = endPt,
                                strokeWidth = 2f + t1 * 4f
                            )
                        }
                    }

                    // Helper to get lane center at given y progress
                    fun getLaneCenter(lane: Int, progress: Float): Offset {
                        val fraction = (lane + 0.5f) / 3f
                        val topX = roadTopLeft.x + (roadTopRight.x - roadTopLeft.x) * fraction
                        val botX = roadBottomLeft.x + (roadBottomRight.x - roadBottomLeft.x) * fraction
                        val currX = topX + (botX - topX) * progress
                        val currY = horizonY + (h - horizonY) * progress
                        return Offset(currX, currY)
                    }

                    // Draw Obstacles / Energy Cores
                    obstacles.forEach { obs ->
                        val pos = getLaneCenter(obs.lane, obs.yProgress)
                        val scale = 0.3f + obs.yProgress * 0.8f

                        if (obs.isPowerup) {
                            // Glowing Energy Core
                            drawCircle(
                                brush = Brush.radialGradient(listOf(NeonCyanGlow, NeonGreen, Color.Transparent)),
                                radius = 22f * scale,
                                center = pos
                            )
                        } else {
                            // Cyber Drone Car
                            val carW = 44f * scale
                            val carH = 26f * scale
                            drawRoundRect(
                                color = NeonRed,
                                topLeft = Offset(pos.x - carW / 2, pos.y - carH / 2),
                                size = Size(carW, carH),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f * scale, 6f * scale)
                            )
                            // Tail glow
                            drawCircle(
                                color = NeonGold,
                                radius = 4f * scale,
                                center = Offset(pos.x - carW / 4, pos.y + carH / 2)
                            )
                            drawCircle(
                                color = NeonGold,
                                radius = 4f * scale,
                                center = Offset(pos.x + carW / 4, pos.y + carH / 2)
                            )
                        }
                    }

                    // Draw Player Cyber Car at bottom
                    val playerPos = getLaneCenter(playerLane, 0.88f)
                    val pWidth = 54f
                    val pHeight = 36f

                    // Cyber Car Body
                    drawRoundRect(
                        brush = Brush.verticalGradient(listOf(NeonCyan, NeonCyanDim)),
                        topLeft = Offset(playerPos.x - pWidth / 2, playerPos.y - pHeight / 2),
                        size = Size(pWidth, pHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                    )

                    // Windshield
                    drawRoundRect(
                        color = CyberBlack,
                        topLeft = Offset(playerPos.x - pWidth * 0.35f, playerPos.y - pHeight * 0.35f),
                        size = Size(pWidth * 0.7f, pHeight * 0.4f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                    )

                    // Turbo exhaust flames
                    val flameColor = if (isTurboActive) NeonRed else NeonPurpleGlow
                    drawCircle(
                        brush = Brush.radialGradient(listOf(flameColor, Color.Transparent)),
                        radius = if (isTurboActive) 20f else 12f,
                        center = Offset(playerPos.x - pWidth * 0.28f, playerPos.y + pHeight * 0.6f)
                    )
                    drawCircle(
                        brush = Brush.radialGradient(listOf(flameColor, Color.Transparent)),
                        radius = if (isTurboActive) 20f else 12f,
                        center = Offset(playerPos.x + pWidth * 0.28f, playerPos.y + pHeight * 0.6f)
                    )
                }

                // Game Over Overlay
                if (isGameOver) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(CyberBlack.copy(alpha = 0.85f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Text(
                                text = "CIRCUIT COMPLETE",
                                color = NeonRed,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Final Score: $score PTS",
                                color = TextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "+${(score / 8).coerceAtLeast(50)} Virtual Demo Coins Earned!",
                                color = NeonGold,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    score = 0
                                    shieldsRemaining = 2
                                    obstacles.clear()
                                    isGameOver = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, tint = CyberBlack)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("PLAY AGAIN", color = CyberBlack, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Controls: Left / Right Steering & Turbo Boost
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Steer Left
            Button(
                onClick = {
                    if (playerLane > 0) playerLane -= 1
                },
                modifier = Modifier
                    .size(68.dp)
                    .testTag("racer_left_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCard)
            ) {
                Icon(Icons.Default.ChevronLeft, contentDescription = "Steer Left", tint = NeonCyan, modifier = Modifier.size(36.dp))
            }

            // Turbo Boost Button
            Button(
                onClick = {
                    isTurboActive = !isTurboActive
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
                    .height(64.dp)
                    .testTag("racer_turbo_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isTurboActive) NeonRed else NeonPurple
                )
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bolt, contentDescription = null, tint = TextPrimary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isTurboActive) "TURBO ENGAGED" else "TAP FOR TURBO",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }

            // Steer Right
            Button(
                onClick = {
                    if (playerLane < 2) playerLane += 1
                },
                modifier = Modifier
                    .size(68.dp)
                    .testTag("racer_right_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCard)
            ) {
                Icon(Icons.Default.ChevronRight, contentDescription = "Steer Right", tint = NeonCyan, modifier = Modifier.size(36.dp))
            }
        }
    }
}
