package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Rocket
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsMotorsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DemoType
import com.example.model.GameCategory
import com.example.model.GameItem
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderGlowing
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanDim
import com.example.ui.theme.NeonCyanGlow
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleDim
import com.example.ui.theme.NeonPurpleGlow
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.ActiveScreen

@Composable
fun NeonTopBar(
    walletBalance: Long,
    isVip: Boolean = false,
    onWalletClick: () -> Unit,
    onVipClick: () -> Unit = {},
    onThemeClick: () -> Unit = {},
    onProfileClick: () -> Unit,
    onAdminClick: () -> Unit
) {
    Surface(
        color = CyberDarkBg,
        border = androidx.compose.foundation.BorderStroke(0.dp, Color.Transparent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // App Branding Logo
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { }
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                if (isVip) listOf(NeonGold, NeonPurple) else listOf(NeonCyan, NeonPurple)
                            )
                        )
                        .border(1.dp, if (isVip) NeonGold else NeonCyanGlow, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isVip) "VIP" else "R3D",
                        color = CyberBlack,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "REENA",
                            color = if (isVip) NeonGold else NeonCyan,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "3D",
                            color = NeonPurpleGlow,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = if (isVip) "VIP ELITE HUB" else "IMAX GAME HUB",
                        color = if (isVip) NeonGold.copy(alpha = 0.8f) else TextMuted,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }
            }

            // Right Actions: VIP Chip + Theme Palette + Wallet + Profile + Admin
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // VIP Status Chip / Unlock Button
                Surface(
                    color = if (isVip) NeonGold.copy(alpha = 0.15f) else CyberCard,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isVip) NeonGold else NeonPurple.copy(alpha = 0.8f)
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onVipClick() }
                        .testTag("top_bar_vip_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (isVip) "👑" else "💎", fontSize = 11.sp)
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = if (isVip) "VIP" else "₹10 VIP",
                            color = if (isVip) NeonGold else NeonPurpleGlow,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                }

                // Theme Switcher Button
                IconButton(
                    onClick = onThemeClick,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(CyberCard)
                        .testTag("top_bar_theme_button")
                ) {
                    Icon(
                        Icons.Default.ColorLens,
                        contentDescription = "Themes",
                        tint = NeonCyan,
                        modifier = Modifier.size(17.dp)
                    )
                }

                // Virtual Demo Coin Chip
                Surface(
                    color = CyberCard,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonGold.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onWalletClick() }
                        .testTag("top_bar_wallet_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🪙", fontSize = 11.sp)
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "$walletBalance",
                            color = NeonGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }

                // Admin Button
                IconButton(
                    onClick = onAdminClick,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(CyberCard)
                        .testTag("top_bar_admin_button")
                ) {
                    Icon(
                        Icons.Default.AdminPanelSettings,
                        contentDescription = "Admin",
                        tint = TextSecondary,
                        modifier = Modifier.size(17.dp)
                    )
                }

                // Profile Avatar Button
                IconButton(
                    onClick = onProfileClick,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(NeonCyanDim, NeonPurpleDim)))
                        .border(1.dp, if (isVip) NeonGold else NeonCyan, CircleShape)
                        .testTag("top_bar_profile_button")
                ) {
                    Icon(
                        Icons.Default.Person,
                        contentDescription = "Profile",
                        tint = TextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun NeonBottomNavigationBar(
    currentScreen: ActiveScreen,
    onNavigate: (ActiveScreen) -> Unit
) {
    NavigationBar(
        containerColor = CyberBlack,
        tonalElevation = 8.dp,
        modifier = Modifier.border(
            width = 1.dp,
            color = CyberBorder,
            shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
        )
    ) {
        val items = listOf(
            Triple(ActiveScreen.Home, "Home", Icons.Default.Home),
            Triple(ActiveScreen.Catalog, "100+ Games", Icons.Default.Gamepad),
            Triple(ActiveScreen.Wallet, "Wallet", Icons.Default.AccountBalanceWallet),
            Triple(ActiveScreen.AiAssistant, "AI Strategist", Icons.Default.SmartToy),
            Triple(ActiveScreen.Profile, "Profile", Icons.Default.Person)
        )

        items.forEach { (screen, label, icon) ->
            val isSelected = currentScreen::class == screen::class
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) NeonCyan else TextMuted
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) NeonCyan else TextMuted
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = CyberCard
                ),
                modifier = Modifier.testTag("nav_${label.lowercase().replace(" ", "_")}")
            )
        }
    }
}

@Composable
fun CategoryPillRow(
    selectedCategory: GameCategory,
    onCategorySelect: (GameCategory) -> Unit
) {
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(GameCategory.values()) { category ->
            val isSelected = selectedCategory == category
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onCategorySelect(category) },
                color = if (isSelected) NeonCyanDim else CyberCard,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) NeonCyan else CyberBorder
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val icon = getCategoryIcon(category)
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = if (isSelected) TextPrimary else TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = category.displayName,
                        color = if (isSelected) TextPrimary else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun GameCard(
    game: GameItem,
    onClick: () -> Unit,
    onPlayClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("game_card_${game.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (game.isPlayableDemo) NeonCyan.copy(alpha = 0.5f) else CyberBorder
        )
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Visual Banner Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(game.primaryColorHex).copy(alpha = 0.45f),
                                Color(game.secondaryColorHex).copy(alpha = 0.25f),
                                CyberBlack
                            )
                        )
                    )
                    .padding(10.dp)
            ) {
                // Category Icon Watermark
                Icon(
                    imageVector = getCategoryIcon(game.category),
                    contentDescription = null,
                    tint = Color(game.primaryColorHex).copy(alpha = 0.35f),
                    modifier = Modifier
                        .size(56.dp)
                        .align(Alignment.BottomEnd)
                )

                // Top Badge & Bookmark
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (game.badge != null) {
                        Surface(
                            color = if (game.isPlayableDemo) NeonCyan else NeonPurple,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = game.badge,
                                color = CyberBlack,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(CyberBlack.copy(alpha = 0.6f))
                    ) {
                        Icon(
                            if (game.isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Favorite",
                            tint = if (game.isFavorite) NeonGold else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Rating & Plays Chip
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .background(CyberBlack.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = NeonGold, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("${game.rating}", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("•", color = TextMuted, fontSize = 10.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("${game.playCount} plays", color = TextSecondary, fontSize = 10.sp)
                }
            }

            // Game Details
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = game.title,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = game.description,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 15.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Action Button
                if (game.isPlayableDemo) {
                    Button(
                        onClick = onPlayClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CyberBlack, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "PLAY 3D DEMO",
                            color = CyberBlack,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    Button(
                        onClick = onClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "VIEW CATALOG SLOT",
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

fun getCategoryIcon(category: GameCategory): ImageVector {
    return when (category) {
        GameCategory.ALL -> Icons.Default.Gamepad
        GameCategory.AVIATOR -> Icons.Default.Flight
        GameCategory.RACING -> Icons.Default.SportsMotorsports
        GameCategory.PUZZLE -> Icons.Default.Extension
        GameCategory.ADVENTURE -> Icons.Default.Explore
        GameCategory.SCI_FI -> Icons.Default.Rocket
        GameCategory.STRATEGY -> Icons.Default.Memory
    }
}
